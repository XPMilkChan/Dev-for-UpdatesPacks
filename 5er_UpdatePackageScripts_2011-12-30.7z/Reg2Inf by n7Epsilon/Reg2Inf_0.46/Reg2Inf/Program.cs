/*
 * Reg2Inf command line front-end code
 */

#region Using Statements
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Ini;
using System.Collections.Epsilon;
using System.Text.RegularExpressions;
#endregion

[assembly: CLSCompliant(false)]

namespace Reg2Inf
{
    partial class Program
    {
        static int Main(string[] args)
        {
            Console.Title = "Reg2Inf Converter " + VariableTable.AppVer;

            // Create FileInfo for both parameters
            try
            {
                // Parse Arguments
                ArgumentParser ArgParser = new ArgumentParser(args);
                ArgParser.Parse(
                    1,
                    8,
                    new string[] { @"linesonly", @"RepVars", @"UseStrings", 
                        @"forceascii", @"noDI", @"noOC", @"longFlags" },
                    new string[] { }, 2,
                    true
                    );

                // Attach Reg2Inf events
                Reg2Inf.Converter converter = new Converter(
                    ArgParser.ParamsTable.ContainsKey("longFlags"));
                converter.onWriteToConsole 
                    += new Converter.writeOutputDelegate(Converter_onWriteToConsole);

                if (ArgParser.ParamsTable.ContainsKey(@"UseStrings"))
                    VariableTable.MakeVariables = true;

                // Program output starts from here
                string InputREGFileStr = null;
                FileInfo InputREGFile = null;
                if (ArgParser.UnhandledParams.Count > 0)
                {
                    InputREGFileStr = ArgParser.UnhandledParams[0].ToString();

                    if (InputREGFileStr.StartsWith("@"))
                    {
                        VariableTable.ListMode = true;
                        InputREGFileStr = InputREGFileStr.Substring(1);
                    }

                    InputREGFile = new FileInfo(InputREGFileStr);
                    if (Directory.Exists(InputREGFile.FullName))
                        throw new ArgumentException("\"" + InputREGFileStr + "\": Is a directory.");

                    if (!InputREGFile.Exists)
                        throw new ArgumentException("\"" + InputREGFileStr + "\": Does not exist.");
                }
                else InputREGFileStr = null;

                string OutputINFFileStr = null;
                FileInfo OutputINFFile = null;
                if (ArgParser.UnhandledParams.Count > 1)
                {
                    OutputINFFileStr = ArgParser.UnhandledParams[1].ToString();
                    OutputINFFile = new FileInfo(OutputINFFileStr);
                    if (Directory.Exists(OutputINFFile.FullName))
                        throw new ArgumentException("\"" + InputREGFileStr + "\": Is a directory.");
                }
                else OutputINFFileStr = null;

                if (!String.IsNullOrEmpty(OutputINFFileStr))
                {
                    if (!ArgParser.ParamsTable.ContainsKey(@"linesonly"))
                    {
                        VariableTable.OutputINF = true;
                    }
                    else
                    {
                        throw new ArgumentException("Conflicting parameters specified!");
                    }
                }
                else VariableTable.OutputINF = false;

                // Variable for storing List mode and normal mode results
                List<INFConversionResult> INFConversionResults = new List<INFConversionResult>(5);

                // Make table if RepVars is specified
                Dictionary<string, string> RepVarTable
                    = new Dictionary<string, string>(30, 
                    StringComparer.CurrentCultureIgnoreCase);
                if (ArgParser.ParamsTable.ContainsKey(@"RepVars"))
                {
                    // Commonly used stuff
                    string WinDir = GetEnv("WinDir");
                    char _slash = Path.DirectorySeparatorChar;
                    string System32 = WinDir + _slash + "SYSTEM32";
                    string SystemDrive = GetEnv("SystemDrive") + _slash;
                    string AllUsersProfile = GetEnv("ALLUSERSPROFILE");
                    string ProgramFiles = GetEnv("ProgramFiles");

                    // Contruct
                    RepVarTable.Add(WinDir, "10");
                    RepVarTable.Add(System32, "11");
                    RepVarTable.Add(System32 + _slash + "drivers", "12");
                    RepVarTable.Add(WinDir + _slash + "INF", "17");
                    RepVarTable.Add(WinDir + _slash + "Help", "18");
                    RepVarTable.Add(WinDir + _slash + "Fonts", "20");
                    RepVarTable.Add(System32 + _slash + "viewers", "21");
                    RepVarTable.Add(System32 + _slash + "spool" + _slash + "drivers" + _slash 
                        + "color", "23");
                    RepVarTable.Add(SystemDrive, "24");
                    RepVarTable.Add(WinDir + _slash + "SYSTEM", "50");
                    RepVarTable.Add(System32 + _slash + "spool", "51");
                    RepVarTable.Add(System32 + _slash + "spool" + _slash + "drivers" + _slash 
                        + "w32x86", "52");
                    RepVarTable.Add(System32 + _slash + "spool" + _slash + "Prtprocs" + _slash 
                        + "w32x86", "55");
                    RepVarTable.Add(AllUsersProfile + _slash + "Start Menu", "16406");
                    RepVarTable.Add(AllUsersProfile + _slash + "Start Menu" + _slash + "Programs", "16407");
                    RepVarTable.Add(AllUsersProfile + _slash + "Start Menu" + _slash + "Programs" 
                        + _slash + "StartUp", "16408");
                    RepVarTable.Add(AllUsersProfile + _slash + "Desktop", "16409");
                    RepVarTable.Add(AllUsersProfile + _slash + "Favorites", "16415");
                    RepVarTable.Add(AllUsersProfile + _slash + "Application Data", "16419");
                    RepVarTable.Add(ProgramFiles, "16422");
                    RepVarTable.Add(AllUsersProfile + _slash + "Templates", "16429");
                    RepVarTable.Add(AllUsersProfile + _slash + "Documents", "16430");
                    RepVarTable.Add(AllUsersProfile + _slash + "Documents" + _slash 
                        + "My Music", "16437");
                    RepVarTable.Add(AllUsersProfile + _slash + "Documents" + _slash 
                        + "My Pictures", "16438");
                }

                // List mode
                if (VariableTable.ListMode)
                {
                    StreamReader ReadListReader = new StreamReader(InputREGFile.FullName, true);
                    string ListData = ReadListReader.ReadToEnd();
                    ReadListReader.Close();
                    if (!Regex.IsMatch(ListData, @"^(Windows\sRegistry\sEditor\sVersion\s5\.00|REGEDIT4)\r\n", RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture))
                    {
                        StringList ListContent = new StringList(ListData.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries));
                        INFConversionResults = new List<INFConversionResult>(ListContent.Count);
                        foreach (string RegFile in ListContent)
                        {
                            FileInfo RegFileInfo = new FileInfo(RegFile);
                            if (RegFileInfo.Exists)
                            {
                                string RegFileFirstLine = new StreamReader(RegFileInfo.FullName).ReadLine().Trim();
                                if (Regex.IsMatch(RegFileFirstLine, @"^(Windows\sRegistry\sEditor\sVersion\s5\.00|REGEDIT4)$", RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture))
                                {
                                    Console.WriteLine("; Processing: \"" + RegFileInfo.Name + "\"");
                                    INFConversionResult Result = converter.Parse(RegFileInfo);
                                    INFConversionResults.Add(Result);
                                }
                                else
                                {
                                    Console.WriteLine("; WARNING: \"" + RegFileInfo.Name + "\": not a valid REG file, Skipped.");
                                    continue;
                                }
                            }
                            else
                            {
                                Console.WriteLine("; WARNING: \"" + RegFileInfo.Name + "\": does not exist, Skipped.");
                                continue;
                            }
                        }
                        if (INFConversionResults.Count == 0)
                        {
                            Warnings.Add("No files were converted!");
                            throw new ApplicationException();
                        }
                    }
                    else
                    {
                        // Failsafe if a person accidentally executed Reg2Inf @"something.reg"
                        VariableTable.ListMode = false;
                    }
                }

                // Output Text Stub
                StringList OutputText = new StringList(new string[] {
                    "[Version]",
                    "Signature=\"$Windows NT$\"",
                    "",
                    "[Optional Components]",
                    "MyRegTweaks",
                    "",
                    "[DefaultInstall]",
                    "AddReg     =REGEntries.AddReg",
                    "DelReg     =REGEntries.DelReg",
                    "",
                    "[MyRegTweaks]",
                    "OptionDesc =\"Registry Entries\"",
                    "Tip        =\"Registry Entries\"",
                    "Modes      =0,1,2,3",
                    "AddReg     =REGEntries.AddReg",
                    "DelReg     =REGEntries.DelReg",
                    "",
                    "[REGEntries.AddReg]",
                    "",
                    "[REGEntries.DelReg]",
                    ""
                    });

                if (VariableTable.MakeVariables)
                {
                    OutputText.Add("[Strings]");
                    OutputText.Add("");
                }

                // Create FileInfo instance for temporary INF file
                FileInfo TempFile = new FileInfo(Path.GetTempFileName());

                // Write OutputStub to it
                StreamWriter WriteOutputStub = new StreamWriter(TempFile.FullName, false);
                foreach (string Line in OutputText) WriteOutputStub.WriteLine(Line);
                WriteOutputStub.Flush();
                WriteOutputStub.Close();

                // Attach to a SimpleINIEditor instance
                SimpleIniEditor TempFileEditor = new SimpleIniEditor(TempFile.FullName);

                if (ArgParser.ParamsTable.ContainsKey("noDI"))
                    TempFileEditor.RemoveSection("DefaultInstall");
                if (ArgParser.ParamsTable.ContainsKey("noOC"))
                {
                    TempFileEditor.RemoveSection("Optional Components");
                    TempFileEditor.RemoveSection("MyRegTweaks");
                }

                // Actual Conversion - NonList mode
                if (!VariableTable.ListMode)
                    INFConversionResults.Add(converter.Parse(InputREGFile));

                // Contruct full AddRegData / DelRegData
                StringBuilder AddRegData = new StringBuilder(500);
                StringBuilder DelRegData = new StringBuilder(200);
                List<String> StringsData = new List<string>(40);

                // Append version info and URL
                AddRegData.AppendLine("; Reg2Inf v" + Converter.Version 
                    + " - " + VariableTable.AppURL);
                DelRegData.AppendLine("; Reg2Inf v" + Converter.Version 
                    + " - " + VariableTable.AppURL);

                foreach (INFConversionResult X in INFConversionResults)
                {
                    AddRegData.AppendLine(X.AddRegData);
                    DelRegData.AppendLine(X.DelRegData);
                    StringsData.AddRange(X.StringsList);
                }

                // Convert to string
                string AddRegDataTotal = AddRegData.ToString()
                    .TrimEnd(new char[] { '\r', '\n' });
                string DelRegDataTotal = DelRegData.ToString()
                    .TrimEnd(new char[] { '\r', '\n' });
                string StringsDataTotal = null;

                // Run the new variable generation code on total result (/UseStrings)
                if (VariableTable.MakeVariables)
                {
                    StringsDataTotal = "; Reg2Inf v" + Converter.Version + 
                        " - " + VariableTable.AppURL + "\r\n" +
                        MakeStringsSection(
                        StringsData,
                        ref AddRegDataTotal,
                        ref DelRegDataTotal);
                }

                // Actual Conversion - AddReg Data
                // Do replacing stuff if /RepVar is specified
                if (ArgParser.ParamsTable.ContainsKey(@"RepVars"))
                {
                    ReplaceVars(ref AddRegDataTotal, RepVarTable);
                }
                TempFileEditor.ReplaceSectionData("REGEntries.AddReg", AddRegDataTotal);

                // Actual Conversion - DelReg Data
                // Do replacing stuff if /RepVar is specified
                if (ArgParser.ParamsTable.ContainsKey(@"RepVars"))
                {
                    ReplaceVars(ref DelRegDataTotal, RepVarTable);
                }
                TempFileEditor.ReplaceSectionData("REGEntries.DelReg", DelRegDataTotal);

                // Actual Compilation - Strings Section if MakeVariables is true
                if (VariableTable.MakeVariables)
                {
                    TempFileEditor.ReplaceSectionData("Strings", StringsDataTotal);
                }

                // Die if any errors occured
                if (Warnings.Count > 0) throw new ApplicationException();

                // Save TempINF file
                if (!ArgParser.ParamsTable.ContainsKey("forceascii"))
                    TempFileEditor.SaveFile(Encoding.Unicode);
                else TempFileEditor.SaveFile(Encoding.Default);

                // Write Output File
                if (VariableTable.OutputINF)
                {
                    // Copy TempINF to output INF
                    TempFile.CopyTo(OutputINFFile.FullName, true);
                }
                else
                {
                    if (ArgParser.ParamsTable.ContainsKey(@"linesonly"))
                    {
                        string AddReg = TempFileEditor.ReadRawSection("REGEntries.AddReg", 
                            false).Trim();
                        string DelReg = TempFileEditor.ReadRawSection("REGEntries.DelReg", 
                            false).Trim();
                        string Strings = String.Empty;
                        if (VariableTable.MakeVariables)
                        {
                            Strings = TempFileEditor.ReadRawSection("Strings", false).Trim();
                        }
                        Console.WriteLine("-- AddReg --");
                        Console.WriteLine(AddReg + "\r\n");
                        Console.WriteLine("-- DelReg --");
                        Console.WriteLine(DelReg + "\r\n");
                        if (VariableTable.MakeVariables)
                        {
                            Console.WriteLine("-- Strings --");
                            Console.WriteLine(Strings + "\r\n");
                        }
                    }
                    else
                    {
                        StreamReader TempFileRead = new StreamReader(TempFile.FullName);
                        string OutputToScreen = TempFileRead.ReadToEnd();
                        TempFileRead.Close();
                        Console.Write(OutputToScreen);
                    }
                }

                Console.Write("; Reg2Inf: Conversion complete");
                if (VariableTable.ErrorsInConversion > 0)
                {
                    Console.Write(", " + VariableTable.ErrorsInConversion + " error(s) occurred. Check output.");
                }
                else Console.Write(", no errors occurred.");
                Console.WriteLine();

                // Finally delete the temporary INF file
                TempFile.Delete();
            }
            catch (ShowUsageException)
            {
                VariableTable.Errorlevel = 0;
                Console.WriteLine(Properties.Resources.UsageInformation,
                    VariableTable.AppName, VariableTable.AppVer, 
                    VariableTable.AppURL);
                Console.WriteLine();
                Console.WriteLine("- Press any key to terminate . . .");
                Console.ReadKey();
            }
            catch (ArgumentException Ex)
            {
                VariableTable.Errorlevel = 5;
                Console.WriteLine(Ex.Message);
            }
            catch (ApplicationException)
            {
                VariableTable.Errorlevel = 1;
                Console.WriteLine();
                Console.WriteLine("; Reg2Inf encountered {0} error(s):", Warnings.Count);
                Console.WriteLine(); 
                TrimArrayListEndFromCarriageReturns(Warnings);
                foreach (string Error in Warnings)
                {
                    Console.WriteLine(wrapForConsole(Error, " ; ", " ; "));
                }
            }
            catch (NotSupportedException Ex)
            {
                VariableTable.Errorlevel = 6;
                Console.WriteLine(Ex.Message);
            }
            catch (Exception Ex)
            {
                VariableTable.Errorlevel = 10;
                Console.WriteLine();
                Console.WriteLine("- Unexpected Exception :");
                Console.WriteLine(Ex.ToString());
                Console.WriteLine();
            }
            return VariableTable.Errorlevel;
        }

        static void Converter_onWriteToConsole(string output)
        {
            string data = wrapForConsole(output, "; ", "; ");
            Console.WriteLine(data);
        }
    }
}
