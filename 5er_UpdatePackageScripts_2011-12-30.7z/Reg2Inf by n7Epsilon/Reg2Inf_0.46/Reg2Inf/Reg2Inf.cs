/*
 REG 2 INF Parser v0.46 - http://tinyurl.com/fgqyf
 Created using Regular Expressions by n7Epsilon (Raif Atef Wasef)

 This class is licensed as GPL and is open-source as long as you credit me if you
 you use it in any of your programs.

 - Made with Microsoft's stuff (VC# 2005 EE), they suck at OSs but looks like 
   they got an IDE right (annoyed at the lack of conditional debugging though)

 - I must thank Aserone and vier from RyanVM.net forums for the reference INF
   and bug-hunting.

 - I must thank Ryan VanderMeulen for his AWESOME work ! None of this would have
   even crossed my mind had I not stumbled upon his awesome update pack project.
*/

#region Using Statements
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Collections;
#endregion

namespace Reg2Inf
{
    public class Converter
    {
        // Version variable
        public const string Version = "0.46";

        // Event system
        public delegate void writeOutputDelegate(string output);
        public event writeOutputDelegate onWriteToConsole;

        // Variables
        private bool showProgress;
        private bool longFlags;

        // Constants
        const string regV4Signature = "REGEDIT4\r\n";
        const string regV5Signature = "Windows Registry Editor Version 5.00\r\n";

        public Converter(bool useLongFlags)
        {
            this.longFlags = useLongFlags;
        }

        #region Static Declarations
        // Let the games Begin !!!!! Init static RegExs for optimization
        static Regex RegexRootKey 
            = new Regex(@"^\[-?(?<RootKey>(HKEY_LOCAL_MACHINE|HKEY_CURRENT_USER|HKEY_CLASSES_ROOT|HKEY_USERS|HKLM|HKCU|HKCR|HKU))", RegexOptions.Multiline | RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture);
        static Regex RegexSubKey 
            = new Regex(@"^\[-?(HKEY_LOCAL_MACHINE|HKEY_CURRENT_USER|HKEY_CLASSES_ROOT|HKEY_USERS|HKLM|HKCU|HKCR|HKU)\\(?<Subkey>.*)\]", RegexOptions.Multiline | RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture);
        static Regex LineSplitter
            = new Regex(@"^[^\r\n\v\t]*[\t\x20]*=[\t\x20]*((\\[\x20\t]*\s*)|[^\r\n])*",
            RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.ExplicitCapture);
        static Regex RegexCommentData 
            = new Regex(@"^\s*;(\s*.*)$", 
            RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.ExplicitCapture);
        static Regex RegexStringValueMatcher
            = new Regex(@"^(@|""(?<Value>.*)"")\s*=\s*\""(?<Data>.*)""([\x20\s]*;+[^\r\n]*)?", 
            RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.ExplicitCapture);
        static Regex RegexOtherValueMatcher
            = new Regex(@"^(@|""(?<Value>.*)"")\s*=\s*(?<Data>[^"";]*)([\x20\s]*;+[^\r\n]*)?",
            RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.ExplicitCapture);

        static Encoding uDecoder = Encoding.Unicode;
        static Encoding aDecoder = Encoding.Default;
        static string SplitToken = @"_!Split" + new Random().Next(99) + "!_";
        static int RegVersionSignature;

        /// <summary>
        /// Method for converting the hex bytestring to a byte value
        /// </summary>
        static byte String2Byte(string ByteString)
        {
            return byte.Parse(ByteString, System.Globalization.NumberStyles.HexNumber);
        }

        /// <summary>
        /// Method for converting the hex bytestring to a byte value + a check
        /// that converts all above ASCII bytes to ?.
        /// </summary>
        static byte String2ByteForASCII(string ByteString)
        {
            byte b = byte.Parse(ByteString, System.Globalization.NumberStyles.HexNumber);
            if (b < 32 || b > 127)
                return 63;
            else return b;
        }

        /// <summary>
        /// Method for converting the hex bytestring to a byte value + a check
        /// that converts all above ASCII bytes to ? but allows CR and LF characters.
        /// </summary>
        static byte String2ByteForASCIIAllowCRLF(string ByteString)
        {
            byte b = byte.Parse(ByteString, System.Globalization.NumberStyles.HexNumber);
            if (b == 13 || b == 10)
                return b;
            if (b < 32 || b > 127)
                return 63;
            else return b;
        }

        /// <summary>
        /// Method for finding empty strings
        /// </summary>
        static bool EmptyString(string item)
        {
            return (item.Length == 0);
        }
        #endregion

        #region Public Method
        /// <summary>
        /// Main method for converting REG files to INF format, spawns a method for each
        /// RegBlock and that spawns a method for each RegLine within that block.
        /// </summary>
        /// <param name="RegFileLoc">Location of REG file</param>
        /// <returns>String of lines to be returned</returns>
        public INFConversionResult Parse(FileInfo RegFileInfo)
        {
            if (!RegFileInfo.Exists)
            {
                Program.WarningAdd(String.Format(
                    "File not found: ({0})", RegFileInfo.Name));
                return new INFConversionResult();
            }

            // Raw Data
            Encoding Encoder = Encoding.GetEncoding(0);
            if (RegFileInfo.Length > 2 * 1024 * 1024)
            {
                showProgress = true;
            }
            StreamReader FileStream 
                = new StreamReader(RegFileInfo.FullName, Encoder, true);
            WriteToConsole(String.Format(
                "Stream: Read to end: \"{0}\"...", RegFileInfo.Name));
            string RawRegFileData = FileStream.ReadToEnd();

            //
            // Nuke all comments (these have given me a royal headache 
            // to try to workaround but it is unfortunately the ONLY way I can do the
            // conversion correctly, the comments confuse the Regular Expression filters)
            //
            // Also the way Reg2Inf processes the lines makes it impossible to know which
            // comment goes where esp. after addition of DelReg support.
            //
            WriteToConsole("Regex: Remove comments...");
            RawRegFileData = Regex.Replace(RawRegFileData, @"^\s*;\s*.*", "\r\n", 
                RegexOptions.Multiline | RegexOptions.ExplicitCapture 
                | RegexOptions.IgnoreCase);

            // Create INFConversionResult Instance
            INFConversionResult Result = new INFConversionResult();

            // Split Data into Array, where each element is a complete registry block
            WriteToConsole("Regex: Add split blocks tokens...");
            RawRegFileData = RegexRootKey.Replace(RawRegFileData, SplitToken + @"$0");
            WriteToConsole("Regex: Split data to blocks...");
            string[] DataArray = Regex.Split(RawRegFileData, SplitToken,
                RegexOptions.IgnoreCase | RegexOptions.Multiline);
            WriteToConsole("Info: Number of blocks: " + DataArray.Length);
            // Free memory (this method takes long to end and GC may 
            // not run wasting a lot of memory)
            WriteToConsole("Memory: GC Collect");
            RawRegFileData = null;
            GC.Collect();

            // Check for Windows REG file signature to determine how to
            // process hex(2) and hex(7) (DBCS or SBCS) and remove from the array
            if (DataArray[0].StartsWith(regV5Signature, 
                StringComparison.OrdinalIgnoreCase))
            {
                RegVersionSignature = 5;
                DataArray[0] = DataArray[0].Remove(0, regV5Signature.Length);
            }
            else if (DataArray[0].StartsWith(regV4Signature, 
                StringComparison.OrdinalIgnoreCase))
            {
                RegVersionSignature = 4;
                DataArray[0] = DataArray[0].Remove(0, regV4Signature.Length);
            }
            else
            {
                Program.WarningAdd(
                    String.Format(
                    "Invalid REG file: ({0})", RegFileInfo.Name));
                return new INFConversionResult();
            }

            // Create output lines
            List<string> OutputLinesAddReg = new List<string>(DataArray.Length);
            List<string> OutputLinesDelReg = new List<string>(20);
            List<string> StringsList = new List<string>(10);

            // Construct output lines array
            foreach (string RegBlock in DataArray)
            {
                INFConversionResult RegBlockOutputResult 
                    = ProcessRegBlock(RegBlock.Trim());
                OutputLinesAddReg.Add(RegBlockOutputResult.AddRegData);
                OutputLinesDelReg.Add(RegBlockOutputResult.DelRegData);
                StringsList.AddRange(RegBlockOutputResult.StringsList);
            }

            // Construct final output string
            StringBuilder OutputStringBuilderAddReg = new StringBuilder();
            StringBuilder OutputStringBuilderDelReg = new StringBuilder();

            foreach (string Line in OutputLinesAddReg)
                if (Line.Length > 0)
                    OutputStringBuilderAddReg.AppendLine(Line);
            
            foreach (string Line in OutputLinesDelReg)
                if (Line.Length > 0)
                    OutputStringBuilderDelReg.AppendLine(Line);

            // Create and return new Result
            INFConversionResult FinalResult = new INFConversionResult();
            FinalResult.AddRegData = OutputStringBuilderAddReg.ToString().Trim();
            FinalResult.DelRegData = OutputStringBuilderDelReg.ToString().Trim();
            FinalResult.StringsList = StringsList;
            return FinalResult;
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Internal method for processing extracted REG format blocks. Real processing takes place here.
        /// </summary>
        /// <param name="RegBlock">Reg Block</param>
        /// <param name="Result">INFConversionResult Instance</param>
        /// <returns>Object containing AddReg or DelReg INF line equivalent to block</returns>
        private INFConversionResult ProcessRegBlock(string RegBlock)
        {
            // Define INFConversionResult instance that will hold the return values
            INFConversionResult RegBlockResult = new INFConversionResult();

            // Define StringBuilders for the final AddReg and DelReg lines
            StringBuilder FinalAddRegLineBuilder = new StringBuilder(100);
            StringBuilder FinalDelRegLineBuilder = new StringBuilder(100);

            // Define variable for RootKey
            string INFRootKey = "_unknown";

            // Extract Root Key
            switch (RegexRootKey.Match(RegBlock).Groups["RootKey"].Value.ToLower())
            {
                case "hkey_local_machine":
                    INFRootKey = "HKLM";
                    break;

                case "hkey_current_user":
                    INFRootKey = "HKCU";
                    break;

                case "hkey_classes_root":
                    INFRootKey = "HKCR";
                    break;

                case "hkey_users":
                    INFRootKey = "HKU";
                    break;

                // Support shorthand reg root key names
                // NOTE: This is not supported by Windows itself, but it is useful for those
                // who write their own REG files by hand.

                case "hklm":
                    INFRootKey = "HKLM";
                    break;

                case "hkcu":
                    INFRootKey = "HKCU";
                    break;

                case "hkcr":
                    INFRootKey = "HKCR";
                    break;

                case "hku":
                    INFRootKey = "HKU";
                    break;
            }

            // Drop line if no valid rootkey found (This will drop all comments too)
            if (INFRootKey == "_unknown") return RegBlockResult;

            // Extract SubKey
            string RawSubKeyName = RegexSubKey.Match(RegBlock).Groups["Subkey"].Value;
            if (RawSubKeyName.Length == 0) return RegBlockResult;
            WriteToConsole(String.Format("Process: [{0}]...", RawSubKeyName));
            string INFSubKeyValue = "\"" + ApplyFixes(RawSubKeyName, true) + "\"";

            // New STRINGS generation support
            if (VariableTable.MakeVariables)
            {
                RegBlockResult.StringsList.Add(
                    INFSubKeyValue.Trim(new char[] { '"', '\x20' }));
            }

            // Check for removal of RegBlock - [-...
            if (Regex.IsMatch(RegBlock, @"^\[-HK", RegexOptions.IgnoreCase 
                | RegexOptions.ExplicitCapture))
            {
                // Then return data to DelReg instead of AddReg property of INFConversionResult instance
                RegBlockResult.DelRegData = INFRootKey + "," + INFSubKeyValue;
                return RegBlockResult;
            }

            // Put RegBlock header out of the way to process lines (Remove header)
            RegBlock = Regex.Replace(RegBlock, RegexSubKey.ToString(), 
                @"", RegexOptions.ExplicitCapture | RegexOptions.IgnoreCase 
                | RegexOptions.Multiline);

            // CleanUp RegBlock from extra carriage returns
            RegBlock = RegBlock.Trim();

            // Check for empty RegBlock (will happen if subkey is empty)
            if (String.IsNullOrEmpty(RegBlock))
            {
                // Return RootKey + Subkey + Key_only flag for accuracy, 
                // to prevent ignoring of empty RegBlocks.
                string Flag = generateStringFlag(RegistryFlag.CreateKeyOnly);
                RegBlockResult.AddRegData = INFRootKey + "," 
                    + INFSubKeyValue + ",," + Flag;
                return RegBlockResult;
            }
            else
            {
                // Filter bad regex
                Match BadLinesMatches = Regex.Match(RegBlock, @"\\\\n\r\r\n", RegexOptions.Singleline);
                if (BadLinesMatches.Success)
                {
                    WriteToConsole("WARNING: Bad newlines found in block: [" 
                        + INFRootKey + "\\" + INFSubKeyValue.Trim(new char[] { '"' }) 
                        + "], they have been replaced by \\r\\n (literally).");
                    RegBlock = RegBlock.Replace("\\\\n\r\r\n", @"\r\n ");
                }

                // Split block into appropriate lines by adding marker after each line
                RegBlock = LineSplitter.Replace(RegBlock, "$0" + SplitToken);
                // Do the actual splitting and cleanup
                List<string> RegLines = new List<string>();
                RegLines.AddRange(Regex.Split(RegBlock, SplitToken + @"\s*",
                    RegexOptions.Multiline | RegexOptions.ExplicitCapture));

                // Internal check for splitter validity
                // The last entry of the array MUST be empty, otherwise
                // something didn't match and that can never be a comment 
                // because we strip them in an earlier stage of processing.
                if (RegLines[RegLines.Count - 1].Length != 0)
                {
                    if (RegLines.Count > 1)
                    {
                        Program.WarningAdd(
                            String.Format(
                            "RegBlock split failed in: [{0}\\{1}]",
                            INFRootKey, INFSubKeyValue.Trim(new char[] { '"' })
                            )
                        );
                    }
                    else
                    {
                        return RegBlockResult;
                    }
                }

                // Force empty RegBlock now (since this block takes long to execute and
                // GC may not collect RegBlock until else block ends, wasting memory
                RegBlock = null;
                GC.Collect();

                // Build more ArrayLists for holding the AddReg and DelReg lines
                List<string> INFAddRegLinesArray = new List<string>(RegLines.Count);
                List<string> INFDelRegLinesArray = new List<string>(RegLines.Count);

                // Pass RegLines to method for figuring out the FLAGS, VALUENAME and VALUEDATA
                foreach (string Line in RegLines)
                {
                    INFConversionResult PartialLineData = ProcessRegLine(Line);
                    if (PartialLineData.AddRegData.Length > 0)
                        INFAddRegLinesArray.Add(PartialLineData.AddRegData);
                    if (PartialLineData.DelRegData.Length > 0)
                        INFDelRegLinesArray.Add(PartialLineData.DelRegData);
                }

                // Compile the final lines for AddReg and DelReg (really this time)
                // AddReg
                foreach (string PartialLine in INFAddRegLinesArray)
                    if (PartialLine.StartsWith(";"))
                    {
                        FinalAddRegLineBuilder.AppendLine(PartialLine);
                        VariableTable.ErrorsInConversion++;
                    }
                    else
                        FinalAddRegLineBuilder.AppendLine(INFRootKey + "," + INFSubKeyValue + "," + PartialLine);
                // DelReg
                foreach (string PartialLine in INFDelRegLinesArray)
                    FinalDelRegLineBuilder.AppendLine(INFRootKey + "," + INFSubKeyValue + "," + PartialLine);
            }

            // Assign the AddReg and DelReg lines to INFConversionResult instance
            RegBlockResult.AddRegData = FinalAddRegLineBuilder.ToString().Trim();
            RegBlockResult.DelRegData = FinalDelRegLineBuilder.ToString().Trim();

            // Return that result instance (which now contains both AddReg and DelReg data)
            return RegBlockResult;
        }

        /// <summary>
        /// Internal method for extracting the data part of the Reg line
        /// </summary>
        /// <param name="Line">Reg Line</param>
        /// <param name="Result">INFConversionResult Instance</param>
        /// <returns>Object containing AddReg or DelReg INF format partial lines for further processing.</returns>
        private INFConversionResult ProcessRegLine(string Line)
        {
            // Create new INFConversionResult to hold result of this method
            INFConversionResult MethodResult = new INFConversionResult();

            // Return empty INFConversionResult instance if Line is empty
            if (String.IsNullOrEmpty(Line)) return MethodResult;
            
            // Flags string definition
            string Flag = String.Empty;
            // ValueNameData string definition
            string ValueNameData = String.Empty;
            // ValueData string definition
            string ValueData = String.Empty;
            // Is ValueData string ?
            bool ValueDataIsString = false;

            // Define Match object that will test all criteria
            Match CriteriaMatch = null;
            CriteriaMatch = RegexStringValueMatcher.Match(Line);
            if (!CriteriaMatch.Success)
            {
                CriteriaMatch = RegexOtherValueMatcher.Match(Line);
            }
            else
            {
                ValueDataIsString = true;
            }
            if (!CriteriaMatch.Success)
            {
                // Make a bug report about it in the output:
                MethodResult.AddRegData 
                    = "; Failed (Invalid syntax): (" + putOnOneLineAndTrim(Line) + ")";
                return MethodResult;
            }

            // Set the value name (blank if default, else valuename)
            ValueNameData = CriteriaMatch.Groups["Value"].Value;

            // Apply fixes to value name data regardless of value data
            ValueNameData = ApplyFixes(ValueNameData, false);

            // Set the value data (string or otherwise, this will be checked later)
            ValueData = CriteriaMatch.Groups["Data"].Value;

            if (ValueDataIsString)
            {
                // Apply fixes
                ValueData = ApplyFixes(ValueData, false);
                // Then we have a normal string value so:
                Flag = generateStringFlag(RegistryFlag.String);
                MethodResult.AddRegData = GenAddRegPartialLine(ValueNameData, 
                    Flag, ValueData, true);
                return MethodResult;
            }
            else
            {
                // --- Other supported possibilities
                // hex(0) : REG_NONE
                // hex(1) : REG_SZ (hex notation only, normal notation should not reach here)
                // hex(2) : REG_EXPAND_SZ
                // hex(3) : REG_BINARY (also hex:)
                // hex(4) : REG_DWORD (also dword:)
                // hex(5) : REG_DWORD_BIG_ENDIAN
                // hex(6) : REG_LINK
                // hex(7) : REG_MULTI_SZ
                // hex(8) : REG_RESOURCE_LIST
                // hex(9) : REG_FULL_RESOURCE_DESCRIPTOR
                // hex(a) : REG_RESOURCE_REQUIREMENTS_LIST
                // hex(b) : REG_QWORD

                // Fix ValueData - Remove SPACE / TAB / CR / LF from beginning and end
                ValueData = ValueData.Trim();

                // If ValueData is equal to -, this means that this is a removal instruction
                // and the line should be added to the DelReg part of the INFConversionResult instance
                if (String.Compare(ValueData, "-") == 0)
                {
                    MethodResult.DelRegData = "\"" + ValueNameData + "\"";
                    return MethodResult;
                }

                // If ValueData is still empty, that means a normal string value with its
                // value explicitly set to blank
                if (String.IsNullOrEmpty(ValueData))
                {
                    Flag = generateStringFlag(RegistryFlag.String);
                    MethodResult.AddRegData = GenAddRegPartialLine(ValueNameData, Flag, ValueData, false);
                    return MethodResult;
                }
                else
                {
                    // Test for the aforementioned possibilities

                    // Binary: [hex:] | [hex(3):] - No reverse of order needed
                    if (Regex.IsMatch(ValueData, @"^hex(\(0*3\))?:(([0-9|A-F]{2}),?)*", RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Multiline))
                    {
                        // Put everything on one line
                        ValueData = putOnOneLineAndTrim(ValueData);
                        // Remove hex: or hex(3): at the beginning
                        ValueData = Regex.Replace(ValueData, @"^hex(\(0*3\))?:", 
                            String.Empty, RegexOptions.IgnoreCase | 
                            RegexOptions.ExplicitCapture | RegexOptions.Singleline);
                        Flag = generateStringFlag(RegistryFlag.Binary);
                        // Return Partial Line
                        MethodResult.AddRegData = GenAddRegPartialLine(ValueNameData, 
                            Flag, ValueData, false);
                        return MethodResult;
                    }

                    // Dword: | [hex(4):]AABBCCDDEEFF (no reverse) | [hex(4):]FF,EE,DD,CC,BB,AA (reverse)
                    if (Regex.IsMatch(ValueData, @"^(dword:([0-9A-Fa-f]){1,8})|(hex\(0*4\):([0-9A-Fa-f]{1,2},?)+)", RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Singleline))
                    {
                        // Remove dword: at the beginning
                        ValueData = Regex.Replace(ValueData, @"^(dword|hex\(0*4\)):", String.Empty, RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Singleline);
                        // Check for empty ValueData
                        if (String.IsNullOrEmpty(ValueData.Trim()))
                        {
                            // Set DWORD flag
                            Flag = generateStringFlag(RegistryFlag.Dword);
                            // Return partial line
                            MethodResult.AddRegData = GenAddRegPartialLine(ValueNameData, Flag, ValueData, false);
                            return MethodResult;
                        }
                        // In case of hex(4) notation, very little changes are needed - no
                        // reverse needed as in hex(4) they are already revered and in the correct format for INF
                        if (Regex.IsMatch(ValueData, @"^([0-9A-Fa-f]{1,2},)+[0-9A-Fa-f]{1,2}$", RegexOptions.ExplicitCapture))
                        {
                            ValueData = ValueData.TrimEnd(new char[] { ',' });
                        }
                        else
                        {
                            // Check if length is equal to 8, else pad with 0s to 8
                            if (ValueData.Length < 8)
                            {
                                int NumberOfZeroesNeeded = 8 - ValueData.Length;
                                for (int i = 0; i < NumberOfZeroesNeeded; i++)
                                {
                                    ValueData = "0" + ValueData;
                                }
                            }
                            // Put a comma after each 2 digits
                            StringBuilder DigitsSeparated = new StringBuilder();
                            MatchCollection SplitThem = Regex.Matches(ValueData,
                            @"(([0-9]|[A-F]){2})", 
                            RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.RightToLeft);
                            DigitsSeparated.Append(SplitThem[0].Value + ",");
                            DigitsSeparated.Append(SplitThem[1].Value + ",");
                            DigitsSeparated.Append(SplitThem[2].Value + ",");
                            DigitsSeparated.Append(SplitThem[3].Value);
                            ValueData = DigitsSeparated.ToString();
                        }
                        // Set DWORD flag
                        Flag = generateStringFlag(RegistryFlag.Dword);
                        // Return partial line
                        MethodResult.AddRegData = GenAddRegPartialLine(ValueNameData, Flag, ValueData, false);
                        return MethodResult;
                    }

                    // hex(2):  |  REG_EXPAND_SZ
                    if (Regex.IsMatch(ValueData, @"^hex\(0*2\):(([0-9|A-F]{2}),?)*", RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Multiline))
                    {
                        // Put everything on one line
                        ValueData = putOnOneLineAndTrim(ValueData);
                        // Remove hex(2): at the beginning
                        ValueData = Regex.Replace(ValueData, @"^hex\(0*2\):", String.Empty, RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Singleline);
                        // Remove trailing 00,00s (v5) or 00s (v4)
                        ValueData = Regex.Replace(ValueData, @",00,00$", String.Empty, RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.ExplicitCapture);

                        // Check for empty ValueData
                        if (String.IsNullOrEmpty(ValueData.Trim()))
                        {
                            // Set Flag
                            Flag = generateStringFlag(RegistryFlag.ExpandString);
                            // Return Partial Line
                            MethodResult.AddRegData = GenAddRegPartialLine(ValueNameData, Flag, ValueData, false);
                            return MethodResult;
                        }
                        // Get the string, with UnicodeEncoding if v5 else ASCIIEncoding
                        if (RegVersionSignature == 5)
                        {
                            // Create an array to hold the hex values
                            List<string> TemporaryArray = new List<string>(ValueData.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));

                            // Treat as DBCS (Double byte characters)
                            List<byte> ByteArray = TemporaryArray.ConvertAll<byte>(String2Byte);
                            ValueData = uDecoder.GetString(ByteArray.ToArray());
                        }
                        else
                        {
                            // Nuke all 00s to prevent conversion to null, if this line causes
                            // changes ValueData then its 99% possible that the wrong REG signature
                            // is present in the REG file being processed.
                            ValueData = Regex.Replace(ValueData, @"00,?", String.Empty);

                            // Create an array to hold the hex values
                            List<string> TemporaryArray = new List<string>(ValueData.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));

                            // Treat as SBCS (Single byte characters)
                            List<byte> ByteArray = TemporaryArray.ConvertAll<byte>(String2ByteForASCII);
                            ValueData = aDecoder.GetString(ByteArray.ToArray());
                        }
                        // Apply Fixes
                        ValueData = ApplyFixes(ValueData, true);
                        // Set Flag
                        Flag = generateStringFlag(RegistryFlag.ExpandString);
                        // Return Partial Line
                        MethodResult.AddRegData = GenAddRegPartialLine(ValueNameData, Flag, ValueData, true);
                        return MethodResult;
                    }

                    // hex(7):  |  REG_MULTI_SZ
                    if (Regex.IsMatch(ValueData, @"^hex\(0*7\):(([0-9|A-F]{2}),?)*", RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Multiline))
                    {
                        // Put everything on one line
                        ValueData = putOnOneLineAndTrim(ValueData);
                        // Remove hex(7): at the beginning
                        ValueData = Regex.Replace(ValueData, @"^hex\(0*7\):", String.Empty, RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Singleline);
                        // Remove trailing 00,00s is now done by the RegEx below the following block

                        // Check for empty ValueData
                        if (String.IsNullOrEmpty(ValueData.Trim()))
                        {
                            // Set Flag - Undocumented but used inside XP Setup's own files to specify 
                            // REG_MULTI_SZ. The documented method seems to be to use 0x10000
                            Flag = generateStringFlag(RegistryFlag.MultiString);
                            // Return Partial Line
                            MethodResult.AddRegData = GenAddRegPartialLine(ValueNameData, Flag, ValueData, false);
                            return MethodResult;
                        }

                        // Create a List<string> for holding the split parts
                        List<string> multiStringEntries = new List<string>(5);

                        // Create a StringBuilder for holding the semi-processed string
                        StringBuilder ValueDataBuilder = new StringBuilder(ValueData.Length);

                        // Convert the bytes back to the string using the new
                        // UnicodeEncoding method for v5 signature (DBCS) and using
                        // the old method for v4 signature which uses SBCS.
                        if (RegVersionSignature == 5)
                        {
                            // RegEx match all pairs of bytes
                            MatchCollection readinTwos = Regex.Matches(
                                ValueData, 
                                @"[a-zA-Z0-9]{2},[a-zA-Z0-9]{2}", 
                                RegexOptions.Multiline 
                                | RegexOptions.IgnoreCase 
                                | RegexOptions.ExplicitCapture);
                            string stringTerminator = "00,00";
                            foreach (Match Found in readinTwos)
                            {
                                if (String.Compare(Found.Value, stringTerminator) != 0)
                                {
                                    List<string> Z = new List<string>(Found.Value.Split(new char[] { ',' }));
                                    List<byte> Y = Z.ConvertAll<byte>(new Converter<string, byte>(String2Byte));
                                    ValueDataBuilder.Append(uDecoder.GetString(Y.ToArray()));
                                }
                                else
                                {
                                    ValueDataBuilder.Append("\r\n");
                                }
                            }
                        }
                        else
                        {
                            // Use old behaviour - invalid and non-printable chars will convert to ? (63)
                            // Convert 00 to a carriage return / line-feed (CR-LF): 0d 0a
                            ValueData = Regex.Replace(ValueData, @"00", @"0d,0a", RegexOptions.Multiline | RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture);
                            // Convert to byte and back to characters using ASCIIEncoding
                            List<string> Z = new List<string>(ValueData.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
                            List<byte> Y = Z.ConvertAll<byte>(new Converter<string, byte>(String2ByteForASCIIAllowCRLF));
                            ValueDataBuilder.Append(aDecoder.GetString(Y.ToArray()));
                        }

                        multiStringEntries.AddRange(Regex.Split(ValueDataBuilder.ToString(), @"\r\n", RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture));
                        // multiStringEntries.RemoveAt((multiStringEntries.Count-1));
                        multiStringEntries.RemoveAll(EmptyString);

                        // Reinit StringBuilder to clear
                        ValueDataBuilder = new StringBuilder(ValueData.Length);

                        for (int i = 0; i < multiStringEntries.Count; i++)
                        {
                            // Apply Fixes
                            multiStringEntries[i] = ApplyFixes(multiStringEntries[i], true);
                            // Append to StringBuilder
                            if ((i + 1) == multiStringEntries.Count)
                                ValueDataBuilder.Append("\"" + multiStringEntries[i] + "\"");
                            else ValueDataBuilder.Append("\"" + multiStringEntries[i] + "\",");
                        }

                        // Set ValueData
                        ValueData = ValueDataBuilder.ToString();
                        // Set Flag - REG_MULTI_SZ overwrite
                        Flag = generateStringFlag(RegistryFlag.MultiString);
                        // Return Partial Line
                        MethodResult.AddRegData = GenAddRegPartialLine(ValueNameData, Flag, ValueData, false);
                        return MethodResult;
                    }

                    // hex(1):  |  REG_SZ expressed in Hex notation
                    if (Regex.IsMatch(ValueData, @"^hex\(0*1\):(([0-9|A-F]{2}),?)*", RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Multiline))
                    {
                        // Put everything on one line
                        ValueData = putOnOneLineAndTrim(ValueData);
                        // Remove hex(1): at the beginning
                        ValueData = Regex.Replace(ValueData, @"^hex\(0*1\):", String.Empty, RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Singleline);
                        // Remove trailing 00,00s
                        ValueData = Regex.Replace(ValueData, @",00,00$", String.Empty, RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.ExplicitCapture);

                        // Check for empty ValueData
                        if (String.IsNullOrEmpty(ValueData.Trim()))
                        {
                            // Set Flag
                            Flag = generateStringFlag(RegistryFlag.String);
                            // Return Partial Line
                            MethodResult.AddRegData = GenAddRegPartialLine(ValueNameData, Flag, ValueData, true);
                            return MethodResult;
                        }
                        // Get the string with UnicodeEncoding
                        // Create an array to hold the hex values
                        List<string> TemporaryArray = new List<string>(ValueData.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));

                        // Treat as DBCS (Double byte characters)
                        List<byte> ByteArray = TemporaryArray.ConvertAll<byte>(String2Byte);
                        ValueData = uDecoder.GetString(ByteArray.ToArray());
                        // Apply Fixes
                        ValueData = ApplyFixes(ValueData, true);
                        // Set Flag
                        Flag = generateStringFlag(RegistryFlag.String);
                        // Return Partial Line
                        MethodResult.AddRegData = GenAddRegPartialLine(ValueNameData, Flag, ValueData, true);
                        // Look for CR + LF and append warning if found
                        if (ValueData.Contains("\r\n"))
                        {
                            MethodResult.AddRegData = MethodResult.AddRegData.Replace("\r\n", "_");
                            MethodResult.AddRegData += "\r\n; WARNING: The string above contained CRLFs which were removed.";
                        }
                        return MethodResult;
                    }

                    // hex(a):  | REG_RESOURCE_REQUIRED
                    if (Regex.IsMatch(ValueData, @"^hex\(0*a\):(([0-9|A-F]{2}),?)*", RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Multiline))
                        return processBinaryType('a', ref ValueNameData, ref ValueData, 
                            generateStringFlag(RegistryFlag.ResourceRequired), ref MethodResult);

                    // hex(b):  | REG_QWORD
                    if (Regex.IsMatch(ValueData, @"^hex\(0*b\):(([0-9|A-F]{2}),?)*", RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Singleline))
                        return processBinaryType('b', ref ValueNameData, ref ValueData, 
                            generateStringFlag(RegistryFlag.Qword), ref MethodResult);

                    // hex(8):  |  REG_RESOURCE_LIST
                    if (Regex.IsMatch(ValueData, @"^hex\(0*8\):(([0-9|A-F]{2}),?)*", RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Multiline))
                        return processBinaryType('8', ref ValueNameData, ref ValueData, 
                            generateStringFlag(RegistryFlag.ResourceList), 
                            ref MethodResult);

                    // hex(9):  |  REG_FULL_RESOURCE_DESCRIPTORS
                    if (Regex.IsMatch(ValueData, @"^hex\(0*9\):(([0-9|A-F]{2}),?)*", RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Multiline))
                        return processBinaryType('9', ref ValueNameData, ref ValueData, 
                            generateStringFlag(RegistryFlag.FullResourceDescriptors), ref MethodResult);

                    // hex(5):  |  REG_DWORD_BIG_ENDIAN
                    if (Regex.IsMatch(ValueData, @"^hex\(0*5\):(([0-9|A-F]{2}),?)*", RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Multiline))
                        return processBinaryType('5', ref ValueNameData, ref ValueData, 
                            generateStringFlag(RegistryFlag.DwordBigEndian), 
                            ref MethodResult);

                    // hex(6):  |  REG_LINK
                    if (Regex.IsMatch(ValueData, @"^hex\(0*6\):(([0-9|A-F]{2}),?)*", RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Multiline))
                        return processBinaryType('6', ref ValueNameData, ref ValueData, 
                            generateStringFlag(RegistryFlag.Link), ref MethodResult);

                    // hex(0):  |  REG_NONE
                    if (Regex.IsMatch(ValueData, @"^hex\(0*0\):(([0-9|A-F]{2}),?)*", RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Multiline))
                        return processBinaryType('0', ref ValueNameData, ref ValueData, 
                            generateStringFlag(RegistryFlag.None), ref MethodResult);

                    // Make a bug report about it in the output:
                    MethodResult.AddRegData = "; Failed (No pattern matched): (\"" + ValueNameData + "\"=" + putOnOneLineAndTrim(ValueData) + ")";
                }
            }

            // Fallback in case nothing matches
            return MethodResult;
        }

        #region Helper methods
        private string generateStringFlag(RegistryFlag flag)
        {
            if (this.longFlags)
                return String.Format("0x{0:X8}", (int)flag);
            else
                return String.Format("0x{0:X0}", (int)flag);
        }

        /// <summary>
        /// Helper method - AddReg ONLY !!!, DelReg syntax will be invalid with this output !!
        /// </summary>
        /// <param name="ValueNameData">ValueNameData</param>
        /// <param name="Flag">Flag, please avoid blank flags, use 0 for string value</param>
        /// <param name="ValueData">ValueData, can be String.Empty</param>
        /// <param name="QuoteValueData">Should quotes be added around ValueData ? - Will be ignored if ValueData = String.Empty</param>
        /// <returns>Partial Line to set as the value of the AddReg property of INFConversionResult instance</returns>
        public static string GenAddRegPartialLine(string ValueNameData, string Flag, string ValueData, bool QuoteValueData)
        {
            // Create StringBuilder to generate output line
            StringBuilder PartialLineToReturn = new StringBuilder(50);
           
            // Check for ValueNameData, is it blank or set to a value ?
            if (String.IsNullOrEmpty(ValueNameData))
                PartialLineToReturn.Append(String.Empty);
            else
                PartialLineToReturn.Append("\"" + ValueNameData + "\"");

            // Flag and ValueData - Here it is a little tricky, Flag must not be appended if
            // blank, but a comma must be appended if ValueData is not empty in order to not
            // break the INF syntax.
            if (String.IsNullOrEmpty(ValueData))
            {
                if (String.IsNullOrEmpty(Flag))
                    PartialLineToReturn.Append(String.Empty);
                else
                {
                    PartialLineToReturn.Append("," + Flag);
                }
            }
            else
            {
                // Doesn't matter here if Flag is empty or not, since if empty
                // the output will indicate a blank Flag with ValueData that indicates
                // a string value.
                if (!QuoteValueData)
                    PartialLineToReturn.Append("," + Flag + "," + ValueData);
                else
                    PartialLineToReturn.Append("," + Flag + ",\"" + ValueData + "\"");
            }

            // Finally return the completed PartialLine
            return PartialLineToReturn.ToString();
        }


        /// <summary>
        /// Common processing for normal binary types
        /// </summary>
        /// <param name="HexType">Single char for hex type eg 'b' in hex(b)</param>
        /// <param name="ValueNameData">Value Name for generating INF format line</param>
        /// <param name="ValueData">ValueData to operate on</param>
        /// <param name="Flag">INF flag for this binary type</param>
        /// <param name="MethodResult">Instance to return result in</param>
        /// <returns>Finished INFConversionResult instance</returns>
        private static INFConversionResult processBinaryType(char HexType, 
            ref string ValueNameData, ref string ValueData, string Flag, 
            ref INFConversionResult MethodResult)
        {
            // Put everything on one line
            ValueData = putOnOneLineAndTrim(ValueData);
            // Remove hex: at the beginning
            ValueData = Regex.Replace(ValueData, @"^hex\(0*" + HexType + @"\):", 
                String.Empty, RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture 
                | RegexOptions.Singleline);
            // Return Partial Line
            MethodResult.AddRegData = GenAddRegPartialLine(ValueNameData, Flag, ValueData, false);
            return MethodResult;
        }

        /// <summary>
        /// Puts ValueData on single line and removes from the beginning and end the following:
        /// space, tab, CR, LF, extra commas
        /// </summary>
        /// <param name="ValueData">ValueData string to operate on</param>
        /// <returns>Cleaned up and fixed string</returns>
        private static string putOnOneLineAndTrim(string ValueData)
        {
            return Regex.Replace(ValueData, 
                @",\\\r\n\s*", @",", RegexOptions.IgnoreCase 
                | RegexOptions.Multiline 
                | RegexOptions.ExplicitCapture)
                .Trim(new char[] { '\r', '\n', '\x20', '\t', ',' });
        }

        /// <summary>
        /// Apply fixes (\\ > \)|(\" > "")|(%% > %)
        /// </summary>
        /// <param name="Line">Line to apply fixes to</param>
        /// <param name="SkipQuotesConversion">REG_MULTI_SZ, REG_SZ (hex notation) and REG_EXPAND_SZ 
        /// already put the quotes correctly so if you fix them again you will damage the value, so for 
        /// those put true here to skip that part and only to do the double-quote and percent fixes.</param>
        /// <returns>New Data</returns>
        private static string ApplyFixes(string Line, bool SkipQuotesConversion)
        {
            if (!SkipQuotesConversion)
            {
                // Change Double backslashes to only one
                Line = Regex.Replace(Line, @"\\\\", @"\",
                    RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.ExplicitCapture);

                // Change escaped quotes to single quote
                Line = Regex.Replace(Line, @"\\""", @"""",
                    RegexOptions.Singleline | RegexOptions.ExplicitCapture | RegexOptions.IgnoreCase);
            }
          
            // Change single quote to double quote
            Line = Regex.Replace(Line, @"""", @"""""", 
                RegexOptions.Singleline | RegexOptions.ExplicitCapture | RegexOptions.IgnoreCase);

            // Code to fix the percentages
            Line =  Regex.Replace(Line, @"%", @"%%", 
                RegexOptions.ExplicitCapture | RegexOptions.Singleline | RegexOptions.IgnoreCase);

            return Line;
        }
        #endregion
        #endregion

        #region Event helpers
        private void WriteToConsole()
        {
            WriteToConsole(String.Empty);
        }
        private void WriteToConsole(string msg)
        {
            if (showProgress)
            {
                if (onWriteToConsole != null)
                {
                    onWriteToConsole(msg);
                }
            }
        }
        #endregion
    }

    [Flags]
    public enum RegistryFlag : int
    {
        String = 0,
        Binary = 0x1,
        MultiString = 0x10000,
        Dword = 0x10001,
        ExpandString = 0x20000,
        None = 0x20001,
        DwordBigEndian = 0x50001,
        Link = 0x60001,
        ResourceList = 0x80001,
        FullResourceDescriptors = 0x90001,
        ResourceRequired = 0xA0001,
        Qword = 0xB0001,

        // Modifier types
        DoNotReplaceExisting = 0x2,
        AppendMultiString = 0x8,
        CreateKeyOnly = 0x10,
        OnlyReplaceExisting = 0x20
    }

    /// <summary>
    /// Define class for holding the conversion results
    /// </summary>
    public sealed class INFConversionResult
    {
        public string AddRegData = String.Empty;
        public string DelRegData = String.Empty;
        public List<string> StringsList = new List<string>(20);
    }
}
