/* Just a simple class for holding all globally accessible variables */

#region Using Statements
using System;
using System.Collections;
using System.Collections.Specialized;
using System.IO;
using System.Text;
#endregion

namespace Reg2Inf
{
    public class VariableTable
    {
        // Global Variables
        public const string AppName = "Reg2Inf";
        public const string AppVer = Converter.Version;
        public const string AppURL = "http://tinyurl.com/fgqyf";

        // Number of errors in conversion
        public static int ErrorsInConversion;

        // Output INF or not ?
        public static bool OutputINF;

        // Errorlevel to return at the end of execution
        public static int Errorlevel;

        // Use [Strings] or not ?
        public static bool MakeVariables;

        // List mode or not ?
        public static bool ListMode;
    
    }
}
