using System;
using System.Collections;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
using System.Text;
using System.Collections.Generic;
using System.Collections.Epsilon;

namespace Reg2Inf
{
    public partial class Program
    {
        // Static ArrayList Definition
        static List<string> Warnings = new List<string>();

        /// <summary>
        /// Add message to list of warnings that is going to be displayed
        /// at the end of program execution.
        /// </summary>
        /// <param name="Message">Message to add to stack</param>
        public static void WarningAdd(string Message)
        {
            Warnings.Add(Message);
        }

        /// <summary>
        /// Environment.GetEnvironmentVariable(string Var)
        /// </summary>
        /// <param name="Var">Var to get</param>
        /// <returns>Var Value</returns>
        public static string GetEnv(string Var)
        {
            return Environment.GetEnvironmentVariable(Var);
        }

        /// <summary>
        /// Replace values with variables
        /// </summary>
        /// <param name="Data">Data to work on</param>
        /// <param name="VarTable">Table of values (case-insensitive)</param>
        /// <returns>New Data</returns>
        public static void ReplaceVars(ref string Data, IDictionary VarTable)
        {
            #region Disabled by design decision
            /* Uncomment this if you want to change all environment variables
             * from DOS-type (%ProgramFiles%) to INF-type (%16422%).
             */

            // Data = Environment.ExpandEnvironmentVariables(Data);             
            #endregion

            // This adds the stuff in the dictionary to an ArrayList and reverses
            // their order to make sure that they are properly substituted
            StringList Sort = new StringList(VarTable.Keys);
            Sort.Sort();
            Sort.Reverse();

            foreach (string X in Sort)
            {
                Data = Regex.Replace(Data, @"""([^""\r\n]*)"
                    + Regex.Escape(X) + @"([^""\r\n]*)""", @"""$1%" + VarTable[X]
                    + @"%$2""", RegexOptions.IgnoreCase | RegexOptions.Multiline);
            }
        }

        /// <summary>
        /// Replace values with variables
        /// </summary>
        /// <param name="Data">Data to work on</param>
        /// <param name="VarTable">Table of values (case-insensitive)</param>
        /// <returns>New Data</returns>
        public static void ReplaceVars(ref string Data, LargeListDictionary VarTable)
        {
            #region Disabled by design decision
            /* Uncomment this if you want to change all environment variables
             * from DOS-type (%ProgramFiles%) to INF-type (%16422%).
             */

            // Data = Environment.ExpandEnvironmentVariables(Data);             
            #endregion

            // This adds the stuff in the dictionary to an ArrayList and reverses
            // their order to make sure that they are properly substituted
            StringList Sort = new StringList(VarTable.Keys);
            Sort.Sort();
            Sort.Reverse();

            foreach (string X in Sort)
            {
                Data = Regex.Replace(Data, @"""([^""\r\n]*)"
                    + Regex.Escape(X) + @"([^""\r\n]*)""", @"""$1%" + VarTable[X]
                    + @"%$2""", RegexOptions.IgnoreCase | RegexOptions.Multiline);
            }
        }

        /// <summary>
        /// Removes \r and/or \n from the last element of the input ArrayList
        /// </summary>
        /// <param name="Input">ArrayList to remove \r and/or \n from its last element</param>
        /// <returns>The modified ArrayList</returns>
        private static void TrimArrayListEndFromCarriageReturns(IList<string> Input)
        {
            // Remove \r\n from last element of this ArrayList
            int LastIndex = Input.Count - 1;
            string LastElement = Input[LastIndex].ToString();
            LastElement = LastElement.TrimEnd(new char[] { '\r', '\n' });
            Input[LastIndex] = LastElement;
        }

        // Replace Variables and construct Strings section
        #region Moved Code (MakeStringsSection)
        public static string MakeStringsSection(List<string> SubKeysToProcess, 
            ref string strOutputStringAddReg, ref string strOutputStringDelReg)
        {
            if (VariableTable.MakeVariables)
            {
                LargeListDictionary VarTable = FindLongestCommonKey(SubKeysToProcess);
                ReplaceVars(ref strOutputStringAddReg, VarTable);
                ReplaceVars(ref strOutputStringDelReg, VarTable);

                StringBuilder StringsSection = new StringBuilder(50);
                foreach (KeyValuePair<string, string> Entry in VarTable)
                {
                    if (!String.IsNullOrEmpty(Entry.Value.ToString()))
                    {
                        StringsSection.Append(Entry.Value.ToString() + " = \"" + Entry.Key.ToString() + "\"\r\n");
                    }
                }
                return StringsSection.ToString();
            }
            else
            {
                throw new InvalidOperationException(
                    "This method should not be invoked since MakeVariables is false.");
            }
        }
        #endregion

        #region New Variable Generation Code
        private static LargeListDictionary FindLongestCommonKey(List<string> InputStrings)
        {
            int StringNumber = 0;
            // Took me a lot of time to figure out.... *sigh*
            List<string> Results = new List<string>(InputStrings.Count);
            InputStrings.Sort(StringComparer.OrdinalIgnoreCase);
            if (InputStrings.Count == 1)
            {
                Results.Add(InputStrings[0].ToString());
            }
            else
            {
                for (int x = 0; x < InputStrings.Count; x++)
                {
                    if (InputStrings[x] == null) continue;
                    string[] Entry = InputStrings[x].ToString().Split(new char[] { '\\' }, 
                        StringSplitOptions.RemoveEmptyEntries);

                    StringBuilder CommonString = new StringBuilder(20);
                    List<int> RemoveFromList = new List<int>(5);
                    for (int i = 0; i < Entry.Length; i++)
                    {
                        string EntryStr = Entry[i];
                        int Tester = 0;
                        for (int y = 0; y < InputStrings.Count; y++)
                        {
                            if (InputStrings[y] == null) continue;
                            string[] CompareEntry = InputStrings[y].ToString().Split(
                                new char[] { '\\' }, StringSplitOptions.RemoveEmptyEntries);
                            if (i >= CompareEntry.Length)
                                break;
                            string TestStr = CompareEntry[i];
                            if (String.Compare(EntryStr, TestStr, true) == 0)
                            {
                                if (!RemoveFromList.Contains(y))
                                {
                                    RemoveFromList.Add(y);
                                }
                                Tester++;
                            }
                            else
                            {
                                break;
                            }
                        }
                        if (Tester > 1)
                        {
                            CommonString.Append(EntryStr);
                            CommonString.Append('\\');
                        }
                        else
                        {
                            break;
                        }
                    }
                    foreach (int RemoveDest in RemoveFromList)
                    {
                        InputStrings[RemoveDest] = null;
                    }
                    // Common string constructed
                    string strCommonString = CommonString.ToString().TrimEnd(
                        new char[] { '\\' });
                    if (!String.IsNullOrEmpty(strCommonString))
                    {
                        RemoveFromList.Clear();
                        Results.Add(strCommonString);
                    }
                }
            }

            // Create ListDictionary
            LargeListDictionary ResultDictionary = new LargeListDictionary(false);
            foreach (string Variable in Results)
            {
                ResultDictionary.Add(Variable, "String" + StringNumber.ToString());
                StringNumber++;
            }
            return ResultDictionary;
        }
        #endregion

        #region WrapForConsole
        /// <summary>
        /// Wraps long messages for display in the console
        /// </summary>
        /// <param name="message">Message to process</param>
        /// <param name="firstLinePrefix">Prefix for 1st line</param>
        /// <param name="normalLinePrefix">Prefix for subsequent lines</param>
        /// <returns>Cleaned up and formatted message</returns>
        public static string wrapForConsole(string message,
                                             string firstLinePrefix,
                                             string normalLinePrefix)
        {
            if (message.Length == 0) return message;
            consoleBuffer.Remove(0, consoleBuffer.Length);
            int maxLength = Console.BufferWidth;
            bool addNewLineAtEnd = false;
            string[] Sentences =
                message.Split(new string[] { Environment.NewLine },
                StringSplitOptions.None);
            int n = 1;
            foreach (string sentence in Sentences)
            {
                if (sentence.Length > 0)
                {
                    int currentLineLength = 0;
                    if (n == 1)
                    {
                        consoleBuffer.Append(firstLinePrefix);
                        currentLineLength = firstLinePrefix.Length;
                    }
                    else
                    {
                        consoleBuffer.Append(normalLinePrefix);
                        currentLineLength = normalLinePrefix.Length;
                    }
                    n++;
                    string[] Words = sentence.Split(' ');
                    foreach (string currentWord in Words)
                    {
                        bool currentLineWillFit =
                            (currentLineLength + currentWord.Length) < maxLength;

                        switch (currentLineWillFit)
                        {
                            case true:
                                consoleBuffer.Append(currentWord);
                                consoleBuffer.Append(' ');
                                currentLineLength += currentWord.Length + 1;
                                continue;

                            case false:
                                if (consoleBuffer[consoleBuffer.Length - 1] == ' ')
                                    consoleBuffer.Remove(consoleBuffer.Length - 1, 1);
                                consoleBuffer.Append(Environment.NewLine);
                                consoleBuffer.Append(normalLinePrefix);
                                consoleBuffer.Append(currentWord);
                                consoleBuffer.Append(' ');
                                currentLineLength =
                                    normalLinePrefix.Length + currentWord.Length + 1;
                                addNewLineAtEnd = true;
                                continue;
                        }
                    }
                }
                consoleBuffer.Remove(
                    consoleBuffer.Length - 1,
                    1);
                consoleBuffer.Append(Environment.NewLine);
            }
            if (!addNewLineAtEnd)
                consoleBuffer.Remove(
                    consoleBuffer.Length - 2,
                    Environment.NewLine.Length);
            return consoleBuffer.ToString();
        }

        /// <summary>
        /// Console buffer, used by wrapForConsole method
        /// </summary>
        private static StringBuilder consoleBuffer = new StringBuilder(300);
        #endregion
    }
}
