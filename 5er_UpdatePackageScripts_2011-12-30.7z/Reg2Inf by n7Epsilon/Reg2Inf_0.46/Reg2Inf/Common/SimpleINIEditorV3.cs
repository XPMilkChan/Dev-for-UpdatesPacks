/* 
 * -------------------------------------------------------------
 * SimpleINIEditor Class, created by n7Epsilon (Raif Atef Wasef)
 * -------------------------------------------------------------
 * 
 *  - Purpose: Process Ini format files using managed code
 * 
 *  - Credits: Sam Habiel, for the C# book and for getting me interested in .NET
 *             in the first place. That book was "C# Unleashed", btw.
 * 
 *  - Special Notes: This was the first proper .NET class I ever made
 * 
 *  - Version 3.92 - Some new features
 *  
 */

#region Using Statements
using System;
using System.Text.RegularExpressions;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Epsilon;
using System.Diagnostics;
#endregion

namespace System.Text.Ini
{
    public sealed class SimpleIniEditor
    {
        // Version variable
        public static Version version = new Version("3.92");

        #region Private variables
        // Data Store - uninitialised
        private LargeListDictionary dataStore;
        #endregion

        #region Delegates
        public delegate void KeyAlreadyExistsHandler(string section, 
            string key);
        public delegate void LineDoesNotMatchHandler(string section, 
            string line);

        /// <summary>
        /// Allows implementing a custom method to check if a line already
        /// exists in a section before adding it.
        /// </summary>
        /// <param name="sectionData">Section data</param>
        /// <param name="lineToProcess">Line to check for</param>
        /// <returns>true if found, else false</returns>
        public delegate bool addLinesCheckIfLineAlreadyExists(
            string sectionName,
            string sectionData,
            string lineToProcess);
        #endregion

        #region Contructors
        /// <summary>
        /// Constructor to modify several lines in same file, where
        /// modifications are to be done in memory and when they are done,
        /// SaveFile method will write the new INI file to disk overwriting
        /// the old one.
        /// </summary>
        /// <param name="Filename">Name of the INI file to edit (must exist)</param>
        /// <param name="nukeComments">Remove all comments before parsing</param>
        public SimpleIniEditor(string Filename)
        {
            if (String.IsNullOrEmpty(Filename))
                throw new ArgumentException(
                    "!!- No INI file specified to process!", 
                    "iniFileToProcess");
            iniFile = new FileInfo(Filename);
            StreamReader streamReadINIFile = new StreamReader(Filename,
                Encoding.Default, true);
            string fileContents = streamReadINIFile.ReadToEnd(); 

            // Close Stream
            streamReadINIFile.Close();

            // Set iniEncoding
            _iniFileEncoding = GetFileEncoding(Filename);

            // Call main initialise method
            Initialise(fileContents);
        }

        /// <summary>
        /// Constructor to attach a SimpleIniEditor to a string.
        /// 
        /// Do not use any of the Save methods with this contructor or you will get an NullReferenceException.
        /// </summary>
        /// <param name="fileContent">Ini file contents</param>
        /// <param name="accessValue">Must be set to 0</param>
        private SimpleIniEditor(string fileContent, int accessValue)
        {
            if (accessValue != 0)
                throw new InvalidOperationException(
                    "!!- Invalid access value for private contructor.");
            iniFile = null;
            Initialise(fileContent);
        }   
        #endregion

        #region Public properties
        /// <summary>
        /// Returns the full path to the INI file that is currently 
        /// being processed by this instance of the class
        /// </summary>
        public FileInfo iniFile;

        private Encoding _iniFileEncoding;

        /// <summary>
        /// Gets the encoding that will be used to save the file by default
        /// Will either be one of the Unicode encodings or the system's current
        /// ANSI code page.
        /// </summary>
        public Encoding iniFileEncoding
        {
            get { return _iniFileEncoding; }
        }

        /// <summary>
        /// Returns a StringList of all the INI file section names
        /// </summary>
        public List<string> Sections
        {
            get { return (List<string>)dataStore.Keys; }
        }

        /// <summary>
        /// Returns a section refcount dictionary
        /// </summary>
        public Dictionary<string, int> refCountSections;

        /// <summary>
        /// Virtual section whose name is randomly generated per
        /// instance, use it to access data present before any
        /// sections are defined in the Ini file.
        /// </summary>
        public readonly string preSectionsDataSectionName =
            "__!R453n64n!%%Misc_!-!4x012_SE" + new Random().Next().ToString();
        #endregion

        #region Public Methods
        /// <summary>
        /// Remove reference to a string from a comma separated list
        /// of references in all instances of a key in a section
        /// case-insensitively
        /// </summary>
        /// <param name="Section">Section</param>
        /// <param name="Key">Key, all instances of this key will be checked
        /// and merged into one instance only in the section.</param>
        /// <param name="ReferenceToRemove">Reference to remove</param>
        public void RemoveReference(string Section, string Key, 
            string ReferenceToRemove)
        {
            StringBuilder finalAddRegLine = new StringBuilder(50);
            StringList addRegReferences = ReadAllInstances(Section, Key);
            StringList holderArray = new StringList();
            foreach (string line in addRegReferences)
            {
                holderArray.AddRange(
                    line.Split(
                    new char[] { ',' },
                    StringSplitOptions.RemoveEmptyEntries)
                );
            }
            holderArray.RemoveAll(new Predicate<string>(
                    delegate(string item)
                    {
                        return
                            String.Equals
                            (
                                item.Trim(),
                                ReferenceToRemove,
                                StringComparison.OrdinalIgnoreCase
                            );
                    }
                )
            );
            foreach (string item in holderArray)
            {
                finalAddRegLine.Append(item.Trim());
                finalAddRegLine.Append(',');
            }
            RemoveLine(Section, Key);
            AddLine(
                Section,
                Key,
                finalAddRegLine.ToString(0, finalAddRegLine.Length - 1)
            );
        }

        /// <summary>
        /// Write data before any sections (useful for INI comments)
        /// </summary>
        /// <param name="data">Data to append</param>
        public void AppendPreSectionData(string data)
        {
            dataStore[preSectionsDataSectionName] 
                = dataStore[preSectionsDataSectionName] + data;
        }

        /// <summary>
        /// Write data before any sections removing any data already there 
        /// (useful for replacing INI comments).
        /// </summary>
        /// <param name="data">Data to put</param>
        public void ReplacePreSectionData(string data)
        {
            dataStore[preSectionsDataSectionName] = data;
        }

        /// <summary>
        /// Replaces section data with other data
        /// </summary>
        /// <param name="Section">Section to alter</param>
        /// <param name="newData">New Data to write in the section in place 
        /// of the old stuff</param>
        public void ReplaceSectionData(string Section, string newData)
        {
            if (!dataStore.TryChangeValue(Section, newData))
                ThrowNotFoundSection(Section);
        }

        /// <summary>
        /// Replaces section data with other data
        /// </summary>
        /// <param name="Section">Section to alter</param>
        /// <param name="newData">New Data to write in the section in place 
        /// of the old stuff</param>
        public void ReplaceSectionData(string Section, StringList newData)
        {
            // Not optimized to use TryChangeValue because any performance
            // benefit would be destroyed by the StringBuilder concatenation
            // process that will occur before the function will be called
            // and this is especially true for larger StringList inputs.
            tryGetSectionData(Section);

            // Change Data in DataStore
            StringBuilder finData = new StringBuilder(85);
            foreach (string Line in newData)
            {
                finData.Append(Line);
                finData.Append(Environment.NewLine);
            }
            dataStore[Section] = finData.ToString(0, finData.Length 
                - Environment.NewLine.Length);
        }

        /// <summary>
        /// Reads an entire section
        /// </summary>
        /// <param name="Section">Section to read</param>
        /// <returns>StringList of lines in that section</returns>
        /// <param name="removeComments">true to remove all comments 
        /// from output</param>
        public StringList Read(string Section)
        {
            return Read(Section, false);
        }

        /// <summary>
        /// Reads an entire section
        /// </summary>
        /// <param name="Section">Section to read</param>
        /// <returns>StringList of lines in that section</returns>
        /// <param name="removeComments">true to remove all comments 
        /// from output</param>
        public StringList Read(string Section, bool removeComments)
        {
            string rawData = ReadRawSection(Section, removeComments);
            StringList data = new StringList(rawData.Split(new string[] { 
                Environment.NewLine, "\n", "\r" }, 
                StringSplitOptions.RemoveEmptyEntries));
            return data;
        }

        /// <summary>
        /// Reads a section into a Dictionary structure, allows for custom
        /// handling of repeated key or invalid syntax situations 
        /// via delegates.
        /// </summary>
        /// <param name="Section">Name of section to read</param>
        /// <param name="handlerOne">Method to handle the condition
        /// where the Regular Expression does not match the line, specify
        /// null to cause the entire line to be added as a key.</param>
        /// <param name="handlerTwo">Method to handle the condition
        /// where a key is present more than once, specify null to
        /// cause the final instance of the key to override the 
        /// value of previous instances (this is the default Windows
        /// behavior).</param>
        /// <returns>Dictionary containing key/value pairs</returns>
        public Dictionary<string, string> ReadIntoPairs(
            string Section, LineDoesNotMatchHandler handlerOne,
            KeyAlreadyExistsHandler handlerTwo)
        {
            StringList listOfPairs = Read(Section, true);
            Dictionary<string, string> pairDictionary
                = new Dictionary<string, string>(listOfPairs.Count,
                StringComparer.CurrentCultureIgnoreCase);
            foreach (string line in listOfPairs)
            {
                Match lineMatched
                    = Regex.Match(line, 
                        @"^(?<Keyword>[^\s]+)\s*=\s*(?<Value>[^\s]+)$",
                    RegexOptions.Singleline | RegexOptions.ExplicitCapture 
                    | RegexOptions.IgnoreCase);
                if (!lineMatched.Success)
                {
                    if (handlerOne != null)
                    {
                        handlerOne(Section, line);
                    }
                    else
                    {
                        pairDictionary.Add(line, String.Empty);
                    }
                }
                else
                {
                    string key = lineMatched.Groups["Keyword"].Value.Trim(
                        '"', ' ', '\t');
                    string value = lineMatched.Groups["Value"].Value.Trim(
                        '"', ' ', '\t');
                    if (!pairDictionary.ContainsKey(key))
                    {
                        pairDictionary.Add(key, value);
                    }
                    else if (handlerTwo != null)
                    {
                        handlerTwo(Section, key);
                    }
                    else
                    {
                        throw new ArgumentException(
                            "Key already exists in dictionary being built.", 
                            key);
                    }
                }
            }
            return pairDictionary;
        }

        /// <summary>
        /// Read raw section data
        /// </summary>
        /// <param name="Section">Section Name</param>
        /// <param name="removeComments">Remove comments from output</param>
        /// <returns>Data in a string (not-splitted)</returns>
        public string ReadRawSection(string Section, bool removeComments)
        {
            string Data;
            if (dataStore.TryGetValue(Section, out Data))
            {
                // Return raw Data
                if (!removeComments)
                    return Data;
                else
                {
                    Data =
                       Regex.Replace(Data,
                       @"^\s*;\s*.*\s*", String.Empty,
                       RegexOptions.Multiline |
                       RegexOptions.ExplicitCapture
                       | RegexOptions.IgnoreCase);
                    Data =
                        Regex.Replace(Data,
                        @"(" + Regex.Escape(Environment.NewLine) + @")+",
                        Environment.NewLine, RegexOptions.Singleline);
                    return Data.Trim();
                }
            }
            else
            {
                ThrowNotFoundSection(Section);
                return null;
            }
        }

        /// <summary>
        /// Try to change the value of a certain key
        /// </summary>
        /// <param name="section">Section that contains the key</param>
        /// <param name="key">Key whose value is to be changed</param>
        /// <param name="newValue">New value for that key</param>
        /// <returns>true if success, false if section not found or key empty or not found</returns>
        public bool TryChangeValue(string section, string key, string newValue)
        {
            return _internalTryChangeMethod(section, key, null, newValue);
        }

        /// <summary>
        /// Try to replace a key with another key at the same position
        /// </summary>
        /// <param name="section">Section which contains the key to replace</param>
        /// <param name="key">Key to replace</param>
        /// <param name="newKey">New key to write in its place</param>
        /// <param name="newValue">Value of the new key</param>
        /// <returns>true if success, false if section not found or key empty or not found</returns>
        public bool TryReplaceKey(string section, string key, string newKey, string newValue)
        {
            return _internalTryChangeMethod(section, key, newKey, newValue);
        }

        /// <summary>
        /// Read the 1st instance of a value in a key/value pair in a certain section
        /// </summary>
        /// <remarks>Throws InvalidOperationException if Section does not exist.</remarks>
        /// <param name="Section">Section</param>
        /// <param name="Key">Key</param>
        /// <returns>Value if Key exists, else String.Empty</returns>
        public string Read(string Section, string Key)
        {
            return _internalReadMethod(Section, Key, true)[0];
        }

        /// <summary>
        /// Read all instances of a value in a key/value pair in a certain section
        /// </summary>
        /// <remarks>Throws InvalidOperationException if Section does not exist.</remarks>
        /// <param name="Section">Section</param>
        /// <param name="Key">Key</param>
        /// <returns>StringList of values of all instances found</returns>
        public StringList ReadAllInstances(string Section, string Key)
        {
            return _internalReadMethod(Section, Key, false);
        }

        /// <summary>
        /// Checks if a section exists
        /// </summary>
        /// <param name="Section">Name of the section to look for</param>
        /// <returns>True or False</returns>
        public bool SectionExists(string Section)
        {
            return dataStore.ContainsKey(Section);
        }

        /// <summary>
        /// Checks if a key (must have a value) exists in a section
        /// </summary>
        /// <param name="Section">Section that contains the key</param>
        /// <param name="Key">The key to look for</param>
        /// <returns>true or false</returns>
        public bool KeyExists(string Section, string Key)
        {
            string TestString;
            if (!dataStore.TryGetValue(Section, out TestString))
            {
                ThrowNotFoundSection(Section);
                return false;
            }
            else
            {
                // Return result of Regex
                return Regex.IsMatch(TestString, @"^\s*(?!;)\s*" 
                    + Regex.Escape(Key) + @"\s*=\s*.*$", 
                    RegexOptions.Multiline | RegexOptions.IgnoreCase);
            }
        }

        /// <summary>
        /// Checks if a line (must NOT have a value) exists in a section
        /// </summary>
        /// <param name="Section">Section that contains the key</param>
        /// <param name="Key">The line to look for</param>
        /// <returns>true or false</returns>
        public bool LineExists(string Section, string Line)
        {
            string TestString;
            if (!dataStore.TryGetValue(Section, out TestString))
            {
                ThrowNotFoundSection(Section);
                return false;
            }
            else
            {
                // Return result of Regex
                return Regex.IsMatch(TestString, @"^\s*(?!;)\s*"
                    + Regex.Escape(Line) + @"\s*$",
                    RegexOptions.Multiline | RegexOptions.IgnoreCase);
            }
        }

        /// <summary>
        /// Adds a new blank section to the INI file
        /// </summary>
        /// <param name="Section">Name of the section to add</param>
        public void AddSection(string Section)
        {
            if (!dataStore.ContainsKey(Section))
            {
                dataStore.Add(Section, String.Empty);
                refCountSections.Add(Section, 1);
            }
            else
            {
                throw new InvalidOperationException("Section being added already exists: " + Section);
            }
        }

        /// <summary>
        /// Adds a new section to the INI file
        /// </summary>
        /// <param name="Section">Name of the section to add</param>
        /// <param name="Data">Data it will contain</param>
        public void AddSection(string Section, string Data)
        {
            if (!dataStore.ContainsKey(Section))
            {
                dataStore.Add(Section, Data);
                refCountSections.Add(Section, 1);
            }
            else
            {
                throw new InvalidOperationException("Section being added already exists: " + Section);
            }
        }

        /// <summary>
        /// Adds a new section to the INI file
        /// </summary>
        /// <param name="Section">Name of the section to add</param>
        /// <param name="Data">Data it will contain</param>
        public void AddSection(string Section, IList<string> Data)
        {
            if (!dataStore.ContainsKey(Section))
            {
                StringBuilder Builder = new StringBuilder(100);
                foreach (string line in Data)
                {
                    Builder.Append(line);
                    Builder.Append(Environment.NewLine);
                }
                if (Builder.Length > 0)
                {
                    dataStore.Add(Section, Builder.ToString(0,
                        Builder.Length - Environment.NewLine.Length));
                }
                else
                {
                    dataStore.Add(Section, Builder.ToString());
                }
                refCountSections.Add(Section, 1);
            }
            else
            {
                throw new InvalidOperationException("Section being added already exists: " + Section);
            }
        }

        /// <summary>
        /// Adds a new section to the INI file
        /// </summary>
        /// <param name="Section">Name of the section to add</param>
        /// <param name="Data">Data it will contain</param>
        public void AddSection(string Section, IDictionary<string, string> Data)
        {
            if (!dataStore.ContainsKey(Section))
            {
                StringBuilder Builder = new StringBuilder(100);
                foreach (KeyValuePair<string, string> Entry in Data)
                {
                    Builder.Append(Entry.Key);
                    Builder.Append(" = ");
                    Builder.Append(Entry.Value);
                    Builder.Append(Environment.NewLine);
                }
                dataStore.Add(Section, Builder.ToString(0,
                    Builder.Length - Environment.NewLine.Length));
                refCountSections.Add(Section, 1);
            }
            else
            {
                throw new InvalidOperationException("Section being added already exists: " + Section);
            }
        }

        /// <summary>
        /// Adds a SINGLE line to the INI file
        /// </summary>
        /// <param name="Section">Name of the section</param>
        /// <param name="Line">Line to add</param>
        public void AddLine(string Section, string Line)
        {
            _internalAddLineMethod(Section, Line, String.Empty);
        }

        /// <summary>
        /// Adds a key = value pair to an INI file
        /// </summary>
        /// <param name="Section">Name of the section</param>
        /// <param name="Key">Name of the key (in eg: "key = value")</param>
        /// <param name="Value">Name of the value (in eg: "key = value")</param>
        public void AddLine(string Section, string Key, string Value)
        {
            _internalAddLineMethod(Section, Key, Value);
        }

        /// <summary>
        /// Adds an ARRAY of lines to the INI file
        /// </summary>
        /// <param name="Section">Section under which array will be written</param>
        /// <param name="Lines">A string[] array containing the lines to add</param>
        public void AddLine(string Section, IList<string> Lines)
        {
            foreach (string X in Lines)
                _internalAddLineMethod(Section, X, String.Empty);
        }

        /// <summary>
        /// Adds a Dictionary of key = value pairs to the INI file
        /// </summary>
        /// <param name="Section">Section under which pairs will be written</param>
        /// <param name="KeyValuePairs">A case-sensitive IDictionary containing key = value pairs</param>
        public void AddLine(string Section, IDictionary<string, string> KeyValuePairs)
        {
            foreach (KeyValuePair<string, string> Entry in KeyValuePairs)
                _internalAddLineMethod(Section, Entry.Key, Entry.Value);

        }

        /// <summary>
        /// Adds a list of lines to the specified section efficiently
        /// </summary>
        /// <param name="Section">Section</param>
        /// <param name="Lines">List of lines</param>
        /// <param name="AddOnce">true to ensure that lines being added are only
        /// present once in the section.</param>
        public void AddLines(
            string Section,
            IList<string> Lines,
            bool AddOnce)
        {
            AddLines(Section, Lines, AddOnce, addLinesCheckExistenceDefault);
        }

        /// <summary>
        /// Adds a list of lines to the specified section efficiently
        /// </summary>
        /// <param name="Section">Section</param>
        /// <param name="Lines">List of lines</param>
        /// <param name="AddOnce">true to ensure that lines being added are only
        /// present once in the section.</param>
        /// <param name="checkIfExists">Method to check if line exists in a section before adding it.</param>
        public void AddLines(
            string Section, 
            IList<string> Lines, 
            bool AddOnce,
            addLinesCheckIfLineAlreadyExists checkIfExists)
        {
            string data = tryGetSectionData(Section);
            StringBuilder sectionBuilder = new StringBuilder(data);

            foreach (string lineX in Lines)
            {
                string line = lineX.Trim();
                if (line.Length == 0 || line[0] == ';')
                    continue;

                if (AddOnce)
                {
                    bool lineExists = checkIfExists(Section, data, line);
                    if (lineExists)
                        continue;
                }
                sectionBuilder.Append(Environment.NewLine);
                sectionBuilder.Append(line);
                
            }

            if (sectionBuilder.ToString().EndsWith(Environment.NewLine))
                dataStore[Section] = sectionBuilder.ToString(0,
                    sectionBuilder.Length - Environment.NewLine.Length);
            else dataStore[Section] = sectionBuilder.ToString();
        }

        /// <summary>
        /// Default implementation to check if a line already exists
        /// before adding, checks for normal lines or key = value pairs.
        /// </summary>
        /// <param name="sectionData">Section data</param>
        /// <param name="line">Line to check for</param>
        /// <returns>true if found, else false</returns>
        private static bool addLinesCheckExistenceDefault(string sectionName, 
            string sectionData,
            string line)
        {
            if (line.IndexOf('=') > 0)
            {
                Match process = Regex.Match(
                    line,
                    @"\A\s*(?!;)\s*(?<Keyword>[^(\s|;)]*)\s*=\s*(?<Value>.*)"
                    + @"((?=\W$)|\z)",
                    RegexOptions.Singleline
                    | RegexOptions.ExplicitCapture
                    | RegexOptions.Compiled
                    );
                string key = process.Groups["Keyword"].Value;
                string value = process.Groups["Value"].Value;

                return Regex.IsMatch(sectionData,
                @"^\s*(?!;)\s*"
                + Regex.Escape(key)
                + @"\s*=\s*"
                + Regex.Escape(value)
                + @"((?=\W$)|\z)",
                RegexOptions.IgnoreCase
                | RegexOptions.Multiline
                | RegexOptions.ExplicitCapture);
            }
            else
            {
                return Regex.IsMatch(sectionData,
                @"^\s*(?!;)\s*"
                + Regex.Escape(line)
                + @"((?=\W$)|\z)",
                RegexOptions.ExplicitCapture
                | RegexOptions.Multiline
                | RegexOptions.IgnoreCase);                    
            }
        }


        /// <summary>
        /// Removes a line from a section in the INI file.
        /// NOTE: Any text on the same line will also be deleted.
        /// </summary>
        /// <remarks>
        /// 1. Any data on the same line will also be removed.
        /// 2. Only the first occurence of the line will be removed.
        /// </remarks>
        /// <param name="Section">Name of section containing line</param>
        /// <param name="Key">Key to remove</param>
        public void RemoveLine(string Section, string Key)
        {
            _internalRemoveLinemethod(Section, Key, String.Empty);
        }

        /// <summary>
        /// Removes a line from a section in the INI file.
        /// NOTE: Any text on the same line will also be deleted.
        /// </summary>
        /// <remarks>
        /// 1. Any data on the same line will also be removed.
        /// 2. Only the first occurence of the line will be removed.
        /// </remarks>
        /// <param name="Section">Name of section containing line</param>
        /// <param name="Key">Key to remove</param>
        /// <param name="Value">Value to be more specific about which key to remove.</param>
        public void RemoveLine(string Section, string Key, string Value)
        {
            _internalRemoveLinemethod(Section, Key, Value);
        }


        /// <summary>
        /// Removes several lines from a section in the INI file.
        /// </summary>
        /// <remarks>
        /// 1. Any data on the same line will also be removed.
        /// 2. Only the first occurence of the line will be removed.
        /// </remarks>
        /// <param name="Section">Name of section containing line</param>
        /// <param name="Keys">Array of Keys to remove</param>
        public void RemoveLine(string Section, string[] Keys)
        {
            foreach (string Key in Keys)
                _internalRemoveLinemethod(Section, Key, String.Empty);
        }

        /// <summary>
        /// Removes several lines from a section in the INI file.
        /// </summary>
        /// <remarks>
        /// 1. Any data on the same line will also be removed.
        /// 2. Only the first occurence of the line will be removed.
        /// </remarks>
        /// <param name="Section">Name of section containing line</param>
        /// <param name="Keys">IDictionary containing key/value pairs. Ideally should be case-sensitive.</param>
        public void RemoveLine(string Section, IDictionary<string, string> Keys)
        {
            foreach (KeyValuePair<string, string> Pair in Keys)
            {
                _internalRemoveLinemethod(Section, Pair.Key, Pair.Value);
            }
        }


        /// <summary>
        /// Removes a section from an INI file.
        /// </summary>
        /// <remarks>Throws an exception if the section specified doesn't exist in the INI file.</remarks>
        /// <param name="Section">Name of the section to remove.</param>
        public void RemoveSection(string Section)
        {
            _internalRemoveSectionMethod(Section);
        }

        /// <summary>
        /// Removes an array of sections from an INI file.
        /// </summary>
        /// <remarks>Throws an exception if any section specified in the array
        /// doesn't exist in the INI file.</remarks>
        /// <param name="Sections">Array of sections to remove.</param>
        public void RemoveSection(string[] Sections)
        {
            foreach (string Section in Sections)
            {
                _internalRemoveSectionMethod(Section);
            }
        }

        /// <summary>
        /// Sorts the data in a section alphabetically
        /// </summary>
        /// <param name="section">Section to sort</param>
        /// <param name="trimLines">Remove whitespace from lines being sorted</param>
        public void SortSection(string section, bool trimLines)
        {
            string data = tryGetSectionData(section);
            int dataLength = data.Length;
            if (dataLength > 0)
            {
                StringBuilder builder = new StringBuilder(dataLength);
                string[] arrayOfData = data.Split(new string[] 
                    { Environment.NewLine, "\n", "\r" }, StringSplitOptions.RemoveEmptyEntries);
                Array.Sort<string>(arrayOfData, StringComparer.OrdinalIgnoreCase);
                foreach (string Line in arrayOfData)
                {
                    string cleanedLine = Line;
                    if (trimLines) cleanedLine = Line.Trim();
                    string[] linesArray = Regex.Split(cleanedLine,
                    @"\s*=\s*", RegexOptions.Singleline | RegexOptions.Compiled);
                    builder.Append(linesArray[0]);
                    if (linesArray.Length > 1)
                    {
                        builder.Append(' ');
                        builder.Append('=');
                        builder.Append(' ');
                        builder.Append(linesArray[1].Trim());
                    }
                    builder.Append(Environment.NewLine);
                }
                dataStore[section] = builder.ToString(0, builder.Length -
                    Environment.NewLine.Length);
            }
        }

        /// <summary>
        /// Sorts the data in all sections of the ini file alphabetically
        /// </summary>
        /// <param name="trimLines">Remove whitespace from lines being sorted</param>
        public void SortAllSections(bool trimLines)
        {
            foreach (string section in dataStore.Keys)
                SortSection(section, trimLines);
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Initialises the SimpleINIEditor and parses the ini file
        /// </summary>
        /// <param name="fileContents">File contents</param>
        private void Initialise(string fileContents)
        {
            string delimstring = "_!%#(OMGHaxx_BASE!" + new Random().Next().ToString() + "!_";
            string ReplacorStub = Regex.Replace(fileContents, @"^\s*(?<Section>\[.*\])", 
                delimstring + "$1", RegexOptions.Multiline);

            // Initialise the DataStore
            dataStore = new LargeListDictionary();
            string[] RawDataSplitResult = ReplacorStub.Split(
                new string[] { delimstring },
                StringSplitOptions.RemoveEmptyEntries);

            // Create a pre-sections entry
            dataStore.Add(preSectionsDataSectionName, String.Empty);

            // Init refcount table
            refCountSections = new Dictionary<string, int>(RawDataSplitResult.Length,
                StringComparer.OrdinalIgnoreCase);

            if (Regex.IsMatch(RawDataSplitResult[0], @"^(?!(\s*\[[^\]"
                + Regex.Escape(Environment.NewLine) + @"]+\]))[^\[]*",
                RegexOptions.Singleline | RegexOptions.ExplicitCapture))
            {
                // Check if the 1st line contains a section or not (will only detect 
                // comments before the 1st defined section, other comments are considered 
                // part of the data of the sections and are ignored while processing).
                dataStore[preSectionsDataSectionName] = RawDataSplitResult[0];
                RawDataSplitResult[0] = String.Empty;
                refCountSections.Add(preSectionsDataSectionName, 1);
            }

            foreach (string Line in RawDataSplitResult)
            {
                if (Line.Length == 0) continue;

                // RegEx to split section name from its data
                Regex SeparateSectionHeadFromData = new Regex(@"^\s*\[(?<SectionName>[^;\]]*)\](?:\t|\x20)*((["
                    + Regex.Escape(Environment.NewLine) +
                    @"]+(?<SectionData>.*))|\s*)", RegexOptions.Singleline
                    | RegexOptions.IgnoreCase);

                // Add the data into the DataStore
                Match processSeparateSectionFromData = SeparateSectionHeadFromData.Match(Line);
                string SectionName = processSeparateSectionFromData.Groups["SectionName"].Value.Trim();
                string SectionData = processSeparateSectionFromData.Groups["SectionData"].Value.Trim();

                // Add to DataStore if SectionName does not exist in DataStore
                if (!dataStore.ContainsKey(SectionName))
                {
                    // Remove extra carriage returns in section data except for those before comments
                    SectionData = Regex.Replace(SectionData, @"(?:"
                        + Regex.Escape(Environment.NewLine)
                        + @")+(?!(\s*;))", Environment.NewLine, RegexOptions.Singleline);

                    // Add the section name and data
                    dataStore.Add(SectionName, SectionData);

                    // Add to refcount
                    refCountSections.Add(SectionName, 1);
                }
                else
                {
                    // Code to merge duplicate sections
                    // Using StringBuilder would have more cost than string concatenation
                    dataStore[SectionName] = dataStore[SectionName]
                        + Environment.NewLine
                        + SectionData;

                    // Append refcount
                    refCountSections[SectionName] = refCountSections[SectionName] + 1;
                }
            }
        }

        // Return the Encoding of a text file.  Return Encoding.Default if no Unicode
        // BOM (byte order mark) is found.
        private static Encoding GetFileEncoding(String FileName)
        {
            Encoding Result = null;
            FileInfo FI = new FileInfo(FileName);
            FileStream FS = null;
            try
            {
                FS = FI.OpenRead();
                Encoding[] UnicodeEncodings = { 
                    Encoding.BigEndianUnicode, Encoding.Unicode, Encoding.UTF8 };
                for (int i = 0; Result == null && i < UnicodeEncodings.Length; i++)
                {
                    FS.Position = 0;
                    byte[] Preamble = UnicodeEncodings[i].GetPreamble();
                    bool PreamblesAreEqual = true;
                    for (int j = 0; PreamblesAreEqual && j < Preamble.Length; j++)
                    {
                        PreamblesAreEqual = Preamble[j] == FS.ReadByte();
                    }
                    if (PreamblesAreEqual)
                    {
                        Result = UnicodeEncodings[i];
                    }
                }
            }
            catch (IOException) { }
            finally
            {
                if (FS != null)
                {
                    FS.Close();
                }
            }
            if (Result == null)
            {
                Result = Encoding.Default;
            }
            return Result;
        }

        /// <summary>
        /// This is the where all the real work takes place (RegExp match/replace)
        /// </summary>
        /// <param name="Section">Name of the Section</param>
        /// <param name="Key">Key in (key = value)</param>
        /// <param name="Value">Value in (key = value)</param>
        private void _internalAddLineMethod(string Section, string Key, string Value)
        {
            // Clean up input data from whitespace
            string CleanSection = Section.Trim();
            string CleanKey = Key.Trim();
            string CleanValue = Value.Trim();

            // Simple work (thanks to the new system)
            if (dataStore.ContainsKey(CleanSection))
            {
                string separator = String.Empty;
                if (dataStore[CleanSection].Length > 0)
                    separator = Environment.NewLine;

                // One Liner
                if (!String.IsNullOrEmpty(CleanValue))
                    dataStore[CleanSection] =
                        dataStore[CleanSection]
                        .TrimEnd(new char[] { ' ', '\t', '\r', '\n' }) 
                        + separator + CleanKey + " = " + CleanValue;
                else
                    dataStore[CleanSection] =
                        dataStore[CleanSection]
                        .TrimEnd(new char[] { ' ', '\t', '\r', '\n' }) 
                        + separator + CleanKey;

            }
            else
            {
                // Add new section with the line inside the DataStore
                if (!String.IsNullOrEmpty(CleanValue))
                    dataStore.Add(CleanSection, CleanKey);
                else
                    dataStore.Add(CleanSection, CleanKey + " = " + CleanValue);
                refCountSections.Add(Section, 1);
            }
        }

        /// <summary>
        /// Internal method to remove lines or key/value pairs from an INI file section.
        /// </summary>
        /// <remarks>
        /// Note:
        /// 1. It will only remove the first occurence found in the section.
        /// 2. Anything on the same line will also be removed in case the value is set to String.Empty.
        /// 3. It throws an exception when the specified section does not exist.
        /// </remarks>
        /// <param name="Section">Name of section to remove line from.</param>
        /// <param name="Key">Key (or Line) to be removed.</param>
        /// <param name="Value">Value to be more specific about which line to remove.</param>
        private void _internalRemoveLinemethod(string Section, string Key, string Value)
        {
            // Clean up input data from whitespace
            string CleanSection = Section.Trim();
            string CleanKey = Key.Trim();
            string CleanValue = Value.Trim();

            string data = tryGetSectionData(CleanSection);

            if (!String.IsNullOrEmpty(Key))
            {
                // Escape Key Name to act as constant in RegEx pattern
                string EscapedKey = Regex.Escape(CleanKey);

                // Escape Value to act as constant in RegEx pattern
                string EscapedValue = Regex.Escape(CleanValue);

                // Removal code
                if (String.IsNullOrEmpty(CleanValue))
                {
                    // RegEx Instance
                    Regex FindLineToRemove = new Regex(@"[\r\n]*" 
                        + EscapedKey 
                        + @"[^\r\n]*[\r\n]*", RegexOptions.Singleline | RegexOptions.IgnoreCase);

                    // Actual Removal
                    dataStore[CleanSection] = FindLineToRemove.Replace(data, 
                        Environment.NewLine, 1).Trim();
                }
                else
                {
                    // RegEx Instance
                    Regex FindLineToRemove = new Regex(@"^" 
                        + EscapedKey 
                        + @"\s*=\s*" 
                        + EscapedValue 
                        + @"\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);

                    // Actual Removal
                    dataStore[CleanSection] = FindLineToRemove.Replace(data, String.Empty, 1);
                }
            }
        }


        /// <summary>
        /// Removes an entire section from an INI file
        /// </summary>
        /// <param name="Section">Name of the section to remove.</param>
        private void _internalRemoveSectionMethod(string Section)
        {
            // Remove from DataStore
            string CleanSection = Section.Trim();
            if (!dataStore.Remove(CleanSection))
                ThrowNotFoundSection(CleanSection);
            else refCountSections.Remove(Section);
        }

        /// <summary>
        /// Internal method to read the value of a key/value pair in a certain section
        /// </summary>
        /// <remarks>Throws InvalidOperationException if Section does not exist.</remarks>
        /// <param name="Section">Section</param>
        /// <param name="Key">Key</param>
        /// <returns>Value if Key exists, else String.Empty</returns>
        private StringList _internalReadMethod(string Section, string Key, bool FirstInstanceOnly)
        {
            string outputFromDataStore;
            if (!dataStore.TryGetValue(Section, out outputFromDataStore))
            {
                ThrowNotFoundSection(Section);
                return null;
            }
            else
            {
                // Use RegExp to extract key data
                Regex MatchInstance = new Regex(@"^\s*(?!;)\s*(?<Keyword>"
                    + Regex.Escape(Key) + @")\s*=\s*(?<Value>.*)((?=\W$)|\z)",
                    RegexOptions.Multiline | RegexOptions.IgnoreCase);
                // Get MatchCollection
                MatchCollection Matches = MatchInstance.Matches(outputFromDataStore);
                // Contruct StringList of values to return
                StringList instancesFoundList;

                if (Matches.Count == 0)
                    return new StringList(new string[] { String.Empty });

                if (!FirstInstanceOnly)
                {
                    instancesFoundList = new StringList(Matches.Count);
                    // Return sum of all data returned in all Matches inside the MatchCollection
                    foreach (Match M in Matches)
                    {
                        instancesFoundList.Add(M.Groups["Value"].Value);
                    }
                }
                else
                {
                    instancesFoundList = new StringList(1);
                    instancesFoundList.Add(Matches[0].Groups["Value"].Value);
                }

                // Return the value
                return instancesFoundList;
            }
        }

        /// <summary>
        /// Internal method for replacing keys or changing values in a section
        /// </summary>
        /// <param name="section">Section which contains the key to replace or change value for</param>
        /// <param name="key">Key to replace or change value for</param>
        /// <param name="newKey">New key to write in its place (null for changing value of key only)</param>
        /// <param name="newValue">Value of the new key (or new value of key to change if newKey is null)</param>
        /// <returns>The result of the IsMatch method on the Regex object dynamically constructed to match key</returns>
        private bool _internalTryChangeMethod(string section, string key, string newKey, string newValue)
        {
            string sectionData;
            string cleanSection = section.Trim();
            string cleanKey = key.Trim();
            string cleanNewValue = newValue.Trim();

            if (!dataStore.TryGetValue(cleanSection, out sectionData))
                return false;
            else if (!String.IsNullOrEmpty(cleanKey))
            {
                // Escape Key Name to act as constant in RegEx pattern
                string EscapedKey = Regex.Escape(cleanKey);

                // Escape Value to act as constant in RegEx pattern
                string EscapedValue = Regex.Escape(cleanNewValue);

                // Construct Regex
                Regex findLineToChange =
                    new Regex(@"^" + EscapedKey + @"\s*=\s*.*$",
                    RegexOptions.Multiline | RegexOptions.IgnoreCase);

                if (findLineToChange.IsMatch(sectionData))
                {
                    string replacementKey;
                    if (newKey == null)
                        replacementKey = cleanKey;
                    else if (newKey.Length > 0)
                        replacementKey = newKey.Trim();
                    else return false;

                    // Do the replace
                    sectionData = findLineToChange.Replace(
                        sectionData,
                        replacementKey + " = " + cleanNewValue
                        );

                    // Replace in dataStore
                    dataStore[cleanSection] = sectionData;

                    return true;
                }
                else return false;
            }
            else return false;
        }

        /// <summary>
        /// Internal Method for saving INI files
        /// </summary>
        /// <param name="Input">Input StringList containing INI file sections</param>
        /// <param name="FileToSave">Name of the INI file to save them to</param>
        /// <param name="EncodingToSaveIn">The output INI file encoding</param>
        private void _internalSaveFileMethod(FileInfo fileToSave, Encoding encodingToSaveIn)
        {
            StreamWriter INISaver = new StreamWriter(fileToSave.FullName, false, encodingToSaveIn);
            foreach (KeyValuePair<string, string> Entry in dataStore)
            {
                string Key = Entry.Key;
                string Value;

                bool isPreSection = (String.Compare(Key, preSectionsDataSectionName, false) == 0);

                if (isPreSection)
                {
                    Value = Entry.Value.Trim(new char[] { '\r', '\n', '\t', ' ' });
                }
                else
                {
                    Value = Entry.Value;
                }
                if (!isPreSection)
                {
                    INISaver.WriteLine("[" + Key + "]");
                }
                INISaver.WriteLine(Value);

                if (!isPreSection)
                {
                    if (!Regex.IsMatch(Value, @"\s*;\s*[^" +
                        Regex.Escape(Environment.NewLine) +
                        @"]*\s*$", RegexOptions.Singleline | RegexOptions.IgnoreCase))
                    {
                        INISaver.WriteLine(String.Empty);
                    }
                }

            }
            INISaver.Flush();
            INISaver.Close();
        }

        #endregion

        #region Static Methods
        /// <summary>
        /// Creates a new Ini file
        /// </summary>
        /// <param name="pathToIniFile">Path to the ini file to create</param>
        /// <param name="encodingToUse">Encoding to use for this file</param>
        /// <param name="overwrite">true to overwrite if file exists</param>
        /// <returns>SimpleINIEditor instance to control the ini file</returns>
        public static SimpleIniEditor Create(string pathToIniFile, 
            Encoding encodingToUse, bool overwrite)
        {
            string iniFile = Path.GetFullPath(pathToIniFile);
            StreamWriter newIniFileWriter =
                new StreamWriter(iniFile, overwrite, encodingToUse);
            newIniFileWriter.WriteLine(
                "; Created by SimpleINIEditor v" + version.ToString(3)
            );
            newIniFileWriter.Flush();
            newIniFileWriter.Close();
            return new SimpleIniEditor(pathToIniFile);
        }

        /// <summary>
        /// Gets a SimpleIniEditor instance from a string.
        /// </summary>
        /// <param name="fileContent">Ini file contents</param>
        /// <param name="fileName">File path to use when saving</param>
        /// <returns>a SimpleINIEditor instance</returns>
        public static SimpleIniEditor FromString(
            string fileContent,
            string fileName)
        {
            SimpleIniEditor newEditor = new SimpleIniEditor(fileContent, 0);
            newEditor.iniFile = new FileInfo(fileName);
            return newEditor;
        }
        #endregion

        #region Internal Save Methods
        /// <summary>
        /// Writes the INI file specified in the constructor to
        /// disk with the detected encoding while parsing the file.
        /// </summary>
        public void SaveFile()
        {
            _internalSaveFileMethod(iniFile, iniFileEncoding);
        }

        /// <summary>
        /// Writes the INI file specified in the contructor to
        /// disk with the specified encoding.
        /// </summary>
        /// <param name="EncodingType"></param>
        public void SaveFile(Encoding EncodingType)
        {
            _internalSaveFileMethod(iniFile, EncodingType);
        }

        /// <summary>
        /// Writes the INI file modified by the class to 
        /// a specified filepath on the target media with
        /// the detected encoding while parsing the file.
        /// </summary>
        /// <param name="OutputFile">Alternate path to save file</param>
        public void SaveFile(FileInfo outputFile)
        {
            _internalSaveFileMethod(outputFile, iniFileEncoding);
        }

        /// <summary>
        /// Writes the INI file modified by the class to 
        /// a specified filepath on the target media with a
        /// certain specified Encoding.
        /// </summary>
        /// <param name="OutputFile">Alternate path to save file</param>
        /// <param name="EncodingToSaveIn">Encoding with which file will be written</param>
        public void SaveFile(FileInfo outputFile, Encoding EncodingToSaveIn)
        {
            _internalSaveFileMethod(outputFile, EncodingToSaveIn);
        }
        #endregion

        #region Internal helper methods
        /// <summary>
        /// Gets the data in a section if it exists, otherwise throws an exception.
        /// </summary>
        /// <param name="cleanSection">Trimmed name of the section</param>
        /// <returns>Section data</returns>
        private string tryGetSectionData(string cleanSection)
        {
            string data = dataStore[cleanSection];
            if (data == null)
                throw new
                    InvalidOperationException(
                    "The section \""
                    + cleanSection
                    + "\" does not exist!");
            else 
                return data;
        }

        /// <summary>
        /// Throws an exception to say Section not found.
        /// </summary>
        /// <param name="SectionName">Section to say doesn't exist</param>
        private static void ThrowNotFoundSection(string SectionName)
        {
            throw new InvalidOperationException("The section \"" 
                + SectionName + "\" does not exist!");
        }
        #endregion
    }
}
