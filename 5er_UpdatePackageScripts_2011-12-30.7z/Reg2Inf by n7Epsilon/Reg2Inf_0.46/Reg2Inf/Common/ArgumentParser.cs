/* 
 * Argument Parser: Reloaded (v2 Trunk)
 */

#region Using statements
using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Epsilon;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
using System.Collections.Generic;
#endregion

namespace System
{
    public class ArgumentParser
    {
        public Version Version = new Version("2.4");

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="args">Array containing arguments to process</param>
        public ArgumentParser(string[] args)
        {
            this.ArgsList.AddRange(args);
        }

        #region Public members
        // StringList of unhandled parameters
        public StringList UnhandledParams = new StringList(5);

        // StringDictionary for Type II parameters
        public StringDictionary ParamsTable = new StringDictionary();

        /// <summary>
        /// Standard method for parsing arguments, It is assumed that the arguments
        /// are in this format: (/arg1 /var:value) (ie: ArgumentSwitch is '/' and
        /// Value/Variable delimiter is ':') 
        /// These are commonly used in M$ OSs like WinDoze and DOS.
        /// </summary>
        /// <param name="Arguments">String array containing actual arguments to parse.</param>
        /// <param name="MinParams">Absolute minimum no. of mandatory arguments that should be present, any less on the command line will throw an exception.</param>
        /// <param name="MaxParams">Absolute maximum no. of arguments that could be possibly present, any more on the command line will throw an exception.</param>
        /// <param name="NormalAllowed">Array of allowed parameters that do not accept a value</param>
        /// <param name="ComplexAllowed">Array of allowed parameters that must accept a value</param>
        /// <param name="NumberOfAllowedSwitchlessParams">Number of allowed switchless arguments.</param>
        /// <param name="throwOnZeroParameters">true to throw ShowUsageException when no parameters are specified</param>
        public void Parse(int MinParams, int MaxParams, string[] NormalAllowed, string[] ComplexAllowed, int NumberOfAllowedSwitchlessParams, bool throwOnZeroParameters)
        {
            Parse(MinParams, MaxParams, NormalAllowed, ComplexAllowed, NumberOfAllowedSwitchlessParams, throwOnZeroParameters, '/', ':');
        }

        /// <summary>
        /// Advanced method for parsing arguments.
        /// </summary>
        /// <param name="Arguments">String array containing actual arguments to parse.</param>
        /// <param name="MinParams">Absolute minimum no. of mandatory arguments that should be present, any less on the command line will throw an exception.</param>
        /// <param name="MaxParams">Absolute maximum no. of arguments that could be possibly present, any more on the command line will throw an exception.</param>
        /// <param name="NormalAllowed">Array of allowed parameters that do not accept a value</param>
        /// <param name="ComplexAllowed">Array of allowed parameters that must accept a value</param>
        /// <param name="NumberOfAllowedSwitchlessParams">Number of allowed switchless arguments.</param>
        /// <param name="throwOnZeroParameters">true to throw ShowUsageException when no parameters are specified</param>
        /// <param name="ArgSwitch">The character used to indicate a paramter eg: '/' as in '/arg' (Hint: For Linux use '-')</param>
        /// <param name="ArgValueDelimiter">The character that separates the variable from its value in a complex parameter eg: ':' as in '/var:value'</param>
        public void Parse(int MinParams, int MaxParams, string[] NormalAllowed, string[] ComplexAllowed, int NumberOfAllowedSwitchlessParams, bool throwOnZeroParameters, char ArgSwitch, char ArgValueDelimiter)
        {
            try
            {
                if (ArgsList.Count == 0)
                    if (throwOnZeroParameters)
                        throw new ShowUsageException();

                foreach (string HelpArg in new string[] { "/?", "-?", "--help" })
                    if (ArgsList.Contains(HelpArg, false)) throw new ShowUsageException();

                // Check length
                if (ArgsList.Count < MinParams) throw new ArgumentException("Too few parameters! Run program with /? for usage information.");
                if (ArgsList.Count > MaxParams) throw new ArgumentException("Too many parameters! Run program with /? for usage information.");

                // Pass 1 - Find Type I parameters (/Simple)
                int UnhandledParamsSoFar = 0;
                foreach (string Parm in ArgsList)
                {
                    if (!String.IsNullOrEmpty(Parm))
                    {
                        if (Parm.Trim().StartsWith(ArgSwitch.ToString()))
                            FoundParams.Add(Parm.Substring(1));
                        else
                        {
                            if (NumberOfAllowedSwitchlessParams == 0)
                            {
                                throw new ArgumentException("Any argument must be preceded by a '" + ArgSwitch + "'.");
                            }
                            else
                            {
                                UnhandledParamsSoFar++;
                                if (UnhandledParamsSoFar > NumberOfAllowedSwitchlessParams)
                                {
                                    throw new ArgumentException("Too many switchless parameters! Run program with /? for usage information.");
                                }
                                else
                                {
                                    UnhandledParams.Add(Parm);
                                }
                            }
                        }
                    }
                }

                // Validation Routine

                // RegEx validation construction
                StringBuilder RegExpr = new StringBuilder(50);
                RegExpr.Append(@"(^(?<arg>[^" + Regex.Escape(ArgSwitch.ToString()) + Regex.Escape(ArgValueDelimiter.ToString()) + @"]+)");
                RegExpr.Append(@"([" + Regex.Escape(ArgValueDelimiter.ToString()) + @"](?<argvalue>.+))?$)");
                Regex MatchGeneralSwitchFormat = new Regex(RegExpr.ToString(), RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.ExplicitCapture);

                foreach (string CmplxParam in FoundParams)
                {
                    if (String.IsNullOrEmpty(CmplxParam))
                        throw new ArgumentException("Invalid argument syntax specified.");

                    // Process Normal Allowed
                    bool Validated = false;
                    foreach (string Switch in NormalAllowed)
                    {
                        Match Control = MatchGeneralSwitchFormat.Match(CmplxParam);
                        if (!Control.Success)
                        {
                            // Should theorertically never hit here
                            throw new ArgumentException("Invalid argument format: " + "\"" + CmplxParam + "\".");
                        }
                        else
                        {
                            string X1 = Control.Groups["arg"].Value;
                            if (String.Compare(X1, Switch, true) == 0)
                            {
                                if (!Control.Groups["argvalue"].Success)
                                {
                                    Validated = true;
                                    break;
                                }
                                else
                                {
                                    StringList TestForDuplicateSpec = new StringList(ComplexAllowed);
                                    if (TestForDuplicateSpec.Contains(X1, false))
                                    {
                                        Validated = true;
                                        break;
                                    }
                                    else
                                    {
                                        throw new ArgumentException("Argument: " + "\"" + Switch + "\"" + " does not allow a value to be specified.");
                                    }
                                }
                            }
                            else
                            {
                                continue;
                            }
                        }
                    }
                    if (Validated)
                    {
                        AddToDictionary(CmplxParam, ArgSwitch, ArgValueDelimiter);
                        continue;
                    }

                    // Process Complex Allowed
                    foreach (string Switch in ComplexAllowed)
                    {
                        Match Control = MatchGeneralSwitchFormat.Match(CmplxParam);
                        if (!Control.Success)
                        {
                            // Should theorertically never hit here
                            throw new ArgumentException("Invalid argument format: " + "\"" + CmplxParam + "\".");
                        }
                        else
                        {
                            string X1 = Control.Groups["arg"].Value;
                            if (String.Compare(X1, Switch, true) == 0)
                            {
                                if (Control.Groups["argvalue"].Success)
                                {
                                    Validated = true;
                                    break;
                                }
                                else
                                {
                                    throw new ArgumentException("Argument: " + "\"" + Switch + "\"" + " requires a value to be specified.");
                                }
                            }
                            else
                            {
                                continue;
                            }
                        }
                    }

                    // If after all this still not validated, throw exception
                    if (!Validated)
                    {
                        throw new ArgumentException("Invalid argument: " + "\"" + ArgSwitch + CmplxParam + "\". Run program with /? for usage information.");
                    }
                    else
                    {
                        AddToDictionary(CmplxParam, ArgSwitch, ArgValueDelimiter);
                        continue;
                    }
                }

                // Empty the work arrays to decrease memory usage
                ArgsList = null;
                FoundParams = null;
            }

            catch (ShowUsageException)
            {
                throw;
            }
            catch (ArgumentException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion

        #region Private members
        // StringList of all parameters
        private StringList ArgsList = new StringList(10);

        // StringList of found parameters
        private StringList FoundParams = new StringList(10);
        #endregion

        #region Helper method
        /// <summary>
        /// Internal method to add parameters to final Dictionary
        /// </summary>
        /// <param name="CmplxParam">Parameter to process</param>
        /// <param name="Dictionary">Dictionary to add result to.</param>
        private void AddToDictionary(string CmplxParam, char ArgSwitch, char ArgValueDelimiter)
        {
            // Assign data to StringDictionary
            string ArgVariable = String.Empty;
            string ArgValue = String.Empty;
            int delimloc = CmplxParam.Trim().IndexOf(ArgValueDelimiter);

            if (delimloc > 0)
            {
                if (delimloc > 0)
                    ArgVariable = CmplxParam.Substring(0, delimloc);
                if ((delimloc + 1) < CmplxParam.Length)
                    ArgValue = CmplxParam.Substring(delimloc + 1);

                if (!ParamsTable.ContainsKey(ArgVariable))
                {
                    ParamsTable.Add(ArgVariable, ArgValue);
                }
                else
                {
                    throw new ArgumentException("Argument: \"" + ArgSwitch + ArgVariable + "\" is specified more than once.");
                }
            }
            else
            {
                if (!ParamsTable.ContainsKey(CmplxParam))
                {
                    ParamsTable.Add(CmplxParam, null);
                }
                else
                {
                    throw new ArgumentException("Argument: \"" + ArgSwitch + CmplxParam + "\" is specified more than once.");
                }
            }
        }
        #endregion
    }

    #region Show Usage Exception Definition
    // Show Usage Exception Definition
    [Serializable]
    public class ShowUsageException : Exception
    {
        public ShowUsageException() : base("Please catch ShowUsageException and set it to display helpful program usage information instead of this message.") { }
    }
    #endregion
}


