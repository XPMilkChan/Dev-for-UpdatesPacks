/* 
 * LargeListDictionary.cs 
 * Original source: CodeProject (http://www.codeproject.com/csharp/largelistdictionary.asp)
 * Copyright (c) 2004 by Michael Micco
 * 
 * Rewritten by 3psil0N (Raif Atef Wasef) to use .NET 2.0 generics for improved
 * performance and to make it only for KeyValuePair<string,string>.
 * 
 */
using System.Collections.Generic;

namespace System.Collections
{
    /// <summary>
    /// LargeListDictionary acts the same as a ListDictionary but performs well on large lists
    /// while still preserving the order of the list when enumerated over.
    /// </summary>
    public class LargeListDictionary : IDictionary<string, string>, IEnumerable<KeyValuePair<string, string>>
    {
        private int _maxIndex;
        private Dictionary<string, IndexedObject> _itemsByKey;
        private Dictionary<int, IndexedObject> _itemsByIndex;

        #region Contructor
        /// <summary>
        /// Creates a case-sensitive LargeListDictionary (default comparer)
        /// </summary>
        public LargeListDictionary() : this(false) { }

        /// <summary>
        /// Creates a LargeListDictionary
        /// </summary>
        /// <param name="CaseSensitive">false for case-insensitive</param>
        public LargeListDictionary(bool caseSensitive)
        {
            if (caseSensitive)
            {
                _itemsByKey = new Dictionary<string, IndexedObject>();
            }
            else
            {
                _itemsByKey = new Dictionary<string, IndexedObject>(
                    StringComparer.CurrentCultureIgnoreCase);
            }
            _itemsByIndex = new Dictionary<int, IndexedObject>();
            _maxIndex = -1;
        }
        #endregion

        #region IDictionary Members
        /// <summary>
        /// IsReadonly pass-through
        /// </summary>
        public bool IsReadOnly
        {
            get { return false; }
        }

        /// <summary>
        /// Return a LargeListDictionaryEnumerator
        /// </summary>
        /// <returns>IDictionaryEnumerator for a LargeListDictionary</returns>
        public IEnumerator<KeyValuePair<string, string>> GetEnumerator()
        {
            return (new LargeListDictionaryEnumerator(_itemsByIndex, _maxIndex));
        }

        /// <summary>
        /// Item accessor
        /// </summary>
        public string this[string key]
        {
            get
            {
                IndexedObject io;
                if (!_itemsByKey.TryGetValue(key, out io))
                    return null;
                else
                    return io.Value;
            }
            set
            {
                IndexedObject io;
                if (!_itemsByKey.TryGetValue(key, out io))
                    Add(key, value);
                else
                    io.Value = value;
            }
        }

        /// <summary>
        /// Try to get value of
        /// </summary>
        /// <param name="key">key to attempt to get value for</param>
        /// <param name="value">output value if found</param>
        /// <returns>true if found, else false</returns>
        public bool TryGetValue(string key, out string value)
        {
            IndexedObject io;
            if (!_itemsByKey.TryGetValue(key, out io))
            {
                value = null;
                return false;
            }
            else
            {
                value = io.Value;
                return true;
            }
        }

        /// <summary>
        /// Try to change the value
        /// </summary>
        /// <param name="key">key to change value of</param>
        /// <param name="newvalue">new value for key</param>
        /// <returns>true if success, else false</returns>
        public bool TryChangeValue(string key, string newvalue)
        {
            IndexedObject io;
            if (!_itemsByKey.TryGetValue(key, out io))
                return false;
            else
            {
                io.Value = newvalue;
                return true;
            }
        }

        /// <summary>
        /// Remove an item by it's key
        /// </summary>
        /// <param name="key">key of item to remove</param>
        public bool Remove(string key)
        {
            // Remove the object from the hashtable, and also remove the corresponding item from the
            // key list... adjust all the indexes appropriately
            IndexedObject io;
            if (!_itemsByKey.TryGetValue(key, out io))
                return false;
            else
            {
                _itemsByKey.Remove(key);
                _itemsByIndex.Remove(io.Index);
                return true;
            }
        }

        /// <summary>
        /// Removes a specific KeyValuePair from the Dictionary
        /// </summary>
        /// <param name="StringKeyValuePair">StringKeyValuePair to remove</param>
        /// <returns>true if found and removed, else false</returns>
        public bool Remove(KeyValuePair<string, string> StringKeyValuePair)
        {
            IndexedObject io;
            if (!_itemsByKey.TryGetValue(StringKeyValuePair.Key, out io))
                return false;
            else
            {
                if (String.Compare(io.Value, StringKeyValuePair.Value, true) == 0)
                {
                    _itemsByKey.Remove(StringKeyValuePair.Key);
                    _itemsByIndex.Remove(io.Index);
                    return true;
                }
                else return false;
            }
        }

        /// <summary>
        /// Looks for a specific key/value pair
        /// </summary>
        /// <param name="StringKeyValuePair">KeyValuePair to look for</param>
        /// <returns>true if found, else false</returns>
        public bool Contains(KeyValuePair<string, string> StringKeyValuePair)
        {
            IndexedObject io;
            if (!_itemsByKey.TryGetValue(StringKeyValuePair.Key, out io))
                return false;
            else
                if (String.Compare(io.Value, StringKeyValuePair.Value, true) == 0)
                    return true;
                else return false;
        }

        /// <summary>
        /// Returns true if the Dictionary contains the specified key
        /// </summary>
        /// <param name="key">key of item to check for</param>
        /// <returns>true if key is in the dictionary</returns>
        public bool ContainsKey(string key)
        {
            return _itemsByKey.ContainsKey(key);
        }

        /// <summary>
        /// Clears the dictionary
        /// </summary>
        public void Clear()
        {
            _itemsByIndex.Clear();
            _itemsByKey.Clear();
            _maxIndex = -1;
        }

        /// <summary>
        /// Returns an ArrayList of the values in their FIFO sequence
        /// </summary>
        public ICollection<string> Values
        {
            get
            {
                List<string> result = new List<string>(this.Count);
                foreach (KeyValuePair<string, string> de in this)
                {
                    result.Add(de.Value);
                }
                return result;
            }
        }

        /// <summary>
        /// Adds an item to the dictionary
        /// </summary>
        /// <param name="key">key for the object</param>
        /// <param name="value">object to store</param>
        public void Add(string key, string value)
        {
            _maxIndex++;
            int newIndex = _maxIndex;

            IndexedObject io = new IndexedObject(newIndex, key, value);
            _itemsByKey.Add(io.Key, io);
            _itemsByIndex.Add(io.Index, io);
        }

        /// <summary>
        /// Adds a KeyValuePair to the dictionary
        /// </summary>
        /// <param name="StringKeyValuePair">KeyValuePair containing data to add</param>
        public void Add(KeyValuePair<string, string> StringKeyValuePair)
        {
            _maxIndex++;
            int newIndex = _maxIndex;

            IndexedObject io = new IndexedObject(newIndex, StringKeyValuePair.Key, StringKeyValuePair.Value);
            _itemsByKey.Add(io.Key, io);
            _itemsByIndex.Add(io.Index, io);
        }

        /// <summary>
        /// Returns an ArrayList of the keys in their FIFO sequence
        /// </summary>
        public ICollection<string> Keys
        {
            get
            {
                List<string> result = new List<string>(this.Count);
                foreach (KeyValuePair<string, string> de in this)
                {
                    result.Add(de.Key);
                }
                return result;
            }
        }

        /// <summary>
        /// Returns number of items in dictionary
        /// </summary>
        public int Count
        {
            get { return _itemsByKey.Count; }
        }

        /// <summary>
        /// Copies the values in FIFO order to an array.
        /// </summary>
        /// <param name="array">destination Array</param>
        /// <param name="index">index for first item</param>
        public void CopyTo(string[] array, int index)
        {
            this.Values.CopyTo(array, index);
        }

        /// <summary>
        /// Copies the StringKeyValuePairs in FIFO order to an array.
        /// </summary>
        /// <param name="StringKeyValuePairs"></param>
        /// <param name="index"></param>
        public void CopyTo(KeyValuePair<string, string>[] StringKeyValuePairsArray, int index)
        {
            List<KeyValuePair<string, string>> Final = new List<KeyValuePair<string, string>>(this.Count);
            foreach (KeyValuePair<string, string> entry in this)
            {
                Final.Add(entry);
            }
            Final.CopyTo(StringKeyValuePairsArray, index);
        }
        #endregion

        #region IEnumerable Members

        /// <summary>
        /// Gets a LargeListDictionaryEnumerator
        /// </summary>
        /// <returns>LargeListDictionaryEnumerator</returns>
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return (new LargeListDictionaryEnumerator(_itemsByIndex, _maxIndex));
        }

        #endregion

        #region Subclasses

        /// <summary>
        /// Struct for storing the key-value pair with an index
        /// </summary>
        public class IndexedObject
        {
            private int _index;
            private string _object;
            private string _key;

            public IndexedObject(int index, string key, string o)
            {
                _index = index;
                _object = o;
                _key = key;
            }

            public string Key
            {
                get { return _key; }
                /* set {_key = value;} */
            }

            public int Index
            {
                get { return _index; }
                /* set {_index = value;} */
            }

            public string Value
            {
                get { return _object; }
                set { _object = value; }
            }
        }

        /// <summary>
        /// Custom enumerator for LargeListDictionary
        /// </summary>
        public struct LargeListDictionaryEnumerator : IEnumerator<KeyValuePair<string, string>>
        {
            private int _currentIndex;
            private Dictionary<int, IndexedObject> _itemsByIndex;
            private int _maxIndex;

            /// <summary>
            /// Creates an enumerator for LargeListDictionary
            /// </summary>
            /// <param name="itemsByIndex">Dictionary of the items with the index being the key</param>
            /// <param name="maxIndex">maximum index assigned so far to any item in the LargeListDictionary</param>
            public LargeListDictionaryEnumerator(Dictionary<int, IndexedObject> itemsByIndex, int maxIndex)
            {
                _itemsByIndex = itemsByIndex;
                _currentIndex = -1;
                _maxIndex = maxIndex;
            }

            #region IEnumerator Members

            /// <summary>
            /// Gets the key of the current item
            /// </summary>
            public string Key
            {
                get
                {
                    IndexedObject io = _itemsByIndex[_currentIndex];
                    return io.Key;
                }
            }

            /// <summary>
            /// Gets the value of the current item
            /// </summary>
            public string Value
            {
                get
                {
                    IndexedObject io = _itemsByIndex[_currentIndex];
                    return io.Value;
                }
            }

            /// <summary>
            /// Gets the DictionaryEntry of the current item
            /// </summary>
            public KeyValuePair<string, string> Entry
            {
                get
                {
                    IndexedObject io = _itemsByIndex[_currentIndex];
                    return new KeyValuePair<string, string>(io.Key, io.Value);
                }
            }

            /// <summary>
            /// Resets the enumerator
            /// </summary>
            public void Reset()
            {
                _currentIndex = -1;
            }

            /// <summary>
            /// Gets the KeyValuePair entry of the current item
            /// </summary>
            KeyValuePair<string, string> IEnumerator<KeyValuePair<string, string>>.Current
            {
                get { return this.Entry; }
            }

            /// <summary>
            /// Gets the current object (for IEnumerator)
            /// </summary>
            public object Current
            {
                get { return this.Entry; }
            }

            /// <summary>
            /// Increments the indexer.  For the LargeListDictionary, if items have been removed, the next index (+1) may not
            /// have an entry.  Continue to increment until an item is found, or the max is reached.
            /// </summary>
            /// <returns>true if another item has been reached, false if the end of the list is hit.</returns>
            public bool MoveNext()
            {
                while (_currentIndex <= _maxIndex)
                {
                    _currentIndex++;
                    if (_itemsByIndex.ContainsKey(_currentIndex))
                        return true;
                }

                return false;
            }

            /// <summary>
            /// Dispose method
            /// </summary>
            public void Dispose() { }
            #endregion
        }
        #endregion
    }
}
