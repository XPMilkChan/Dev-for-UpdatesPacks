using System.Collections.Generic;

namespace System.Collections.Epsilon
{
    /// <summary>
    /// A strongly-typed list of strings based on generic List, adds
    /// support for case-insensitive operations.
    /// </summary>
    public class StringList : System.Collections.Generic.List<string>
    {
        #region Constructor
        /// <summary>
        /// Creates a new instance of the StringList object
        /// </summary>
        public StringList() : base() { }

        /// <summary>
        /// Creates a new instance of the StringList object
        /// </summary>
        /// <param name="collection">Collection to add in the StringList</param>
        public StringList(List<string> List) : base(List) { }

        /// <summary>
        /// Creates a new instance of the StringList object
        /// </summary>
        /// <param name="array">Array to add in the StringList</param>
        public StringList(string[] array) : base(array) { }

        /// <summary>
        /// Creates a new instance of the StringList object
        /// </summary>
        /// <param name="collection">ICollection to add (all its members will be casted to String)</param>
        public StringList(ICollection collection)
        {
            this.Capacity = collection.Count;
            foreach (string item in collection)
            {
                this.Add(item);
            }
        }

        /// <summary>
        /// Creates a new instance of the StringList object
        /// </summary>
        /// <param name="collection">ICollection`String to add</param>
        public StringList(ICollection<string> collection)
        {
            this.AddRange(collection);
        }

        /// <summary>
        /// Creates a new instance of the StringList object
        /// </summary>
        /// <param name="InitialCapacity">The initial number of elements the StringList will hold</param>
        public StringList(int InitialCapacity) : base(InitialCapacity) { }
        #endregion

        /// <summary>
        /// Checks if an object exists in the StringList, with the ability to be
        /// case-insensitive in case of searching strings.
        /// </summary>
        /// <param name="item">string to look for for</param>
        /// <param name="caseSensitive">false for case-insensitive search</param>
        public bool Contains(string item, bool caseSensitive)
        {
            if (caseSensitive)
                return base.Contains(item);
            else
                foreach (string listitem in this)
                    if (String.Compare(item, listitem, true) == 0)
                        return true;
            return false;
        }

        /// <summary>
        /// Locate index of a string
        /// </summary>
        /// <param name="value">String to look for</param>
        /// <param name="caseSensitive">false for case-insensitive search</param>
        /// <returns>Index of the 1st instance found</returns>
        public int IndexOf(string value, bool caseSensitive)
        {
            if (caseSensitive)
            {
                return base.IndexOf(value);
            }
            else
            {
                for (int i = 0; i < this.Count; i++)
                {
                    if (String.Compare(value, this[i], true) == 0)
                        return i;
                }
                return -1;
            }
        }

        /// <summary>
        /// Removes a string from StringList case-insensitively
        /// </summary>
        /// <param name="value">string to remove</param>
        /// <param name="caseSensitive">false for case-insensitive search</param>
        public void Remove(string value, bool caseSensitive)
        {
            if (caseSensitive)
                base.Remove(value);
            else
            {
                for (int i = 0; i < this.Count; i++)
                {
                    if (String.Compare(value, this[i], true) == 0)
                    {
                        base.RemoveAt(i);
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Locate index of a string
        /// </summary>
        /// <param name="value">string to look for</param>
        /// <param name="caseSensitive">false for case-insensitive search</param>
        /// <param name="startIndex">Index in the StringList to start searching from</param>
        /// <returns>Index of the 1st instance found</returns>
        public int IndexOf(string value, int startIndex, bool caseSensitive)
        {
            if (caseSensitive)
            {
                return base.IndexOf(value, startIndex);
            }
            else
            {
                for (int i = startIndex; i < this.Count; i++)
                {
                    if (String.Compare(value, this[i], true) == 0)
                        return i;
                }
                return -1;
            }
        }

        /// <summary>
        /// Locate index of a string
        /// </summary>
        /// <param name="value">string to look for</param>
        /// <param name="startIndex">Index in the StringList to start searching from</param>
        /// <param name="count">Number of items to look through</param>
        /// <param name="caseSensitive">false for case-insensitive search</param>
        /// <returns>Index of the 1st instance found</returns>
        public int IndexOf(string value, int startIndex, int count, bool caseSensitive)
        {
            if (caseSensitive)
            {
                return base.IndexOf(value, startIndex, count);
            }
            else
            {
                for (int i = startIndex; i < (startIndex + count); i++)
                {
                    if (String.Compare(value, this[i], true) == 0)
                        return i;
                }
                return -1;
            }
        }

        /// <summary>
        /// Locate index of a string
        /// </summary>
        /// <param name="value">string to look for</param>
        /// <param name="caseSensitive">false for case-insensitive search</param>
        /// <returns>Index of the last instance found</returns>
        public int LastIndexOf(string value, bool caseSensitive)
        {
            if (caseSensitive)
            {
                return base.LastIndexOf(value);
            }
            else
            {
                for (int i = (this.Count - 1); i == 0; i--)
                {
                    if (String.Compare(value, this[i], true) == 0)
                        return i;
                }
                return -1;
            }
        }

        /// <summary>
        /// Locate index of a string case-insensitively
        /// </summary>
        /// <param name="value">string to look for</param>
        /// <param name="startIndex">Index in the StringList to start searching before</param>
        /// <param name="caseSensitive">false for case-insensitive search</param>
        /// <returns>Index of the last instance found</returns>
        public int LastIndexOf(string value, int startIndex, bool caseSensitive)
        {
            if (caseSensitive)
            {
                return base.LastIndexOf(value, startIndex);
            }
            else
            {
                for (int i = startIndex; i == 0; i--)
                {
                    if (String.Compare(value, this[i], true) == 0)
                        return i;
                }
                return -1;
            }
        }

        /// <summary>
        /// Locate index of a string case-insensitively
        /// </summary>
        /// <param name="value">string to look for</param>
        /// <param name="startIndex">Index in the StringList to start searching before</param>
        /// <param name="count">Number of items to look through</param>
        /// <param name="caseSensitive">false for case-insensitive search</param>
        /// <returns>Index of the last instance found</returns>
        public int LastIndexOf(string value, int startIndex, int count, bool caseSensitive)
        {
            if (caseSensitive)
            {
                return base.LastIndexOf(value, startIndex, count);
            }
            else
            {
                for (int i = startIndex; i > (startIndex - count); i--)
                {
                    if (String.Compare(value, this[i], true) == 0)
                        return i;
                }
                return -1;
            }
        }
    }
}

